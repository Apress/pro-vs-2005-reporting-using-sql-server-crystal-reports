using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;

using CGS.CrystalReportsTools;
using ConstructionDemo.CrystalReports;
using ConstructionDemo.Datasets;

namespace SimpleReportingDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void btnRun_Click(object sender, EventArgs e)
        {
            switch (this.cboReportList.SelectedIndex)
            {
                case 0:
                    this.RunTimeSheetReport();
                    break;
                case 1:
                    this.RunGanttChart();
                    break;
                case 2:
                    this.RunStackedBarChart();
                    break;
                case 3:
                    this.RunReportGraph();
                    break;
                case 4:
                    this.RunAgingReport();
                    break;
                    //                  this.RunScatterGraph();
//                    break;
            }
        }

        private void RunAgingReport()
        {

            dsAgingReport odsAgingData = new dsAgingReport();


            odsAgingData.ReadXml("c:\\myxmlfiles\\DSagingreport.xml", XmlReadMode.InferSchema);
            RPT_AgingReport oAgingReport = new RPT_AgingReport();
            oAgingReport.SetParameterValue("ShowDetails", false);

            this.GenerateReport(odsAgingData, oAgingReport);
        
        }




        private void RunTimeSheetReport()
        {
            // A full example of launching a report

            // First, create instance of Typed DataSet (tha was used at designtime)
            // dsTimeSheets is in the ConstructionDemo.Datasets namespace
            dsTimeSheets odsTimeSheets = new dsTimeSheets();

            // Normally, we'd go to SQL Server, or some other database, to grab the data and put it into a dataset
            // For simplicity sake, we'll just read in data from an XML file
            odsTimeSheets.ReadXml("c:\\myxmlfiles\\dsTimeSheets.xml", XmlReadMode.InferSchema);
            // So just "make believe" that odsTimeSheets was populated by some back-end data process



            // Create instance of our Crystal Report 
            // RPT_TimeSheet, in the ConstructionDemo.CrystalReports namespace
            RPT_TimeSheet oTimeSheetReport = new RPT_TimeSheet();

       this.GenerateReport(odsTimeSheets, oTimeSheetReport);



            //ccReportInfo oReportInfo = new ccReportInfo();
            //oReportInfo.FtrDataSource = "My XML Data Source";
            //oReportInfo.FtrFootNotes = "My Report Custom Footnotes";
            //oReportInfo.FtrRunBy = "Run by Kevin Goff";
            //oReportInfo.FtrVersion = "Version 1.01";
            //oReportInfo.HdrCompany = "My Construction Company";
            //oReportInfo.HdrReportTitle = "My TimeSheet Report";
            //oReportInfo.HdrSubTitle1 = "Includes Labor Earnings";
            //oReportInfo.HdrSubTitle2 = "";
            //oReportInfo.UserID = "KSG001";



            //// Now, create an instance of our Crystal Reports manager in the CGS.CrystalReports namespace
            ccCrystalManager oCrystalManager = new ccCrystalManager();


            //oCrystalManager.SetReportInfo(oTimeSheetReport,  oReportInfo);

            //oCrystalManager.PushReportData(odsTimeSheets,oTimeSheetReport); 


            //// Depending on which option we took on the form, we can preview, print, or export
            // oCrystalManager.PreviewReport(oTimeSheetReport, "General Preview Screen");   // pretty simple, just pass the report object and a preview caption



             ccCrystalPrintOptionForm oPrintOptionsForm = new ccCrystalPrintOptionForm();
             oPrintOptionsForm.ShowDialog();
             if (oPrintOptionsForm.DialogResult == DialogResult.OK)
             {
                 oCrystalManager.lCollate = oPrintOptionsForm.chkCollateCopies.Checked;
                 oCrystalManager.nCopies = Convert.ToInt32(oPrintOptionsForm.spnNumPrintedCopies.Value);
                 oCrystalManager.lAllPages = oPrintOptionsForm.optPrintAll.Checked;
                 oCrystalManager.lPageRange = oPrintOptionsForm.optPrintRange.Checked;
                 oCrystalManager.cPrinterName = oPrintOptionsForm.cboPrinterList.Text.ToString();

                 if (oPrintOptionsForm.optPrintRange.Checked == true)    {
                     oCrystalManager.nStartPage = Convert.ToInt32(oPrintOptionsForm.txtPrintStartPage.Text);
                     oCrystalManager.nEndPage = Convert.ToInt32(oPrintOptionsForm.txtPrintEndPage.Text);
                 }
                 oCrystalManager.PrintReport(oTimeSheetReport);



             }

            // //            oCrystalManager.PrintReport(oReport);











//            this.GenerateReport(odsTimeSheets, oTimeSheetReport);

        }




        private void RunReportGraph()
        {
            Ds_ReportandGraph odsReportandGraph = new Ds_ReportandGraph();
            odsReportandGraph.ReadXml("c:\\myxmlfiles\\DS_ReportAndGraph.xml", XmlReadMode.InferSchema);

            RPT_CostLaborReportGraph oReportGraph = new RPT_CostLaborReportGraph();



            ccReportInfo oReportInfo = new ccReportInfo();
            oReportInfo.FtrDataSource = "My XML Data Source";
            oReportInfo.FtrFootNotes = "My Report Custom Footnotes";
            oReportInfo.FtrRunBy = "Run by Kevin Goff";
            oReportInfo.FtrVersion = "Version 1.01";
            oReportInfo.HdrCompany = "My Construction Company";
            oReportInfo.HdrReportTitle = "My TimeSheet Report";
            oReportInfo.HdrSubTitle1 = "Includes Labor Earnings";
            oReportInfo.HdrSubTitle2 = "";
            oReportInfo.UserID = "KSG001";



            // Now, create an instance of our Crystal Reports manager in the CGS.CrystalReports namespace
            ccCrystalManager oCrystalManager = new ccCrystalManager();


            oCrystalManager.SetReportInfo(oReportGraph,oReportInfo);

            oCrystalManager.PushReportData(odsReportandGraph, oReportGraph);


            // Depending on which option we took on the form, we can preview, print, or export
            oCrystalManager.PreviewReport(oReportGraph,"General Preview Screen");   // pretty simple, just pass the report object and a preview caption






//            this.GenerateReport(odsReportandGraph, oReportGraph);

        }



        private void RunStackedBarChart()
        {
            Ds_SimpleBarChart odsBarChart = new Ds_SimpleBarChart();
            odsBarChart.ReadXml("c:\\myxmlfiles\\DS_SimpleBarChart.xml", XmlReadMode.InferSchema);

            RPT_CostStackedBarGraph oBarChart = new RPT_CostStackedBarGraph();
 


            this.GenerateReport(odsBarChart, oBarChart);


        }






        private void RunGanttChart()
        {
            dsJobGanttChart odsJobGanttChart = new dsJobGanttChart();
            odsJobGanttChart.ReadXml("c:\\myxmlfiles\\dsGantt.xml", XmlReadMode.InferSchema);
            RPT_JobGanttChart oGanttChart = new RPT_JobGanttChart();
            this.GenerateReport(odsJobGanttChart, oGanttChart);
        }





        
        
        
        
        private void GenerateReport(DataSet dsData, ReportDocument oReport)
        {
            ccReportInfo oReportInfo = new ccReportInfo();
            
            oReportInfo.FtrDataSource = "Test Data Source";
            oReportInfo.FtrFootNotes = "Here are my TimeSheet Footnotes";
            oReportInfo.FtrRunBy = "Run by Kevin S. Goff";
            oReportInfo.FtrVersion = "Version 1.01";
            oReportInfo.HdrCompany = "Test Company";
            oReportInfo.HdrReportTitle = "Test TimeSheet Report";
            oReportInfo.HdrSubTitle1 = "Includes Labor Rates";
            oReportInfo.HdrSubTitle2 = "";
            oReportInfo.UserID = "KSG001";



            // Now, create an instance of our Crystal Reports manager in the CGS.CrystalReports namespace
            ccCrystalManager oCrystalManager = new ccCrystalManager();


            oCrystalManager.SetReportInfo(oReport, oReportInfo);


            // This part is optional, but very powerful
            // The report manager in my framework utilizes a generic page header and page footer for all reports
            // We can specify the following information for the header/footer

            // Next, we need to 'push'  (the Crystal Push Model) the dataset odsTimeSheets into the report object
            // The method PushReportData in our Crystal Manager library will take care of this
            // So just pass it the dataset, an instance of the report, and the header/footer row that we created
                    //    // the method PushReportData returns a basic report object  (a Crystal ReportDocument), we can cast
        //    // the return value to our specific report object 



            oReport = oCrystalManager.PushReportData(dsData, oReport);


        //    // Depending on which option we took on the form, we can preview, print, or export
            if(this.optPreview.Checked==true)
                oCrystalManager.PreviewReport(oReport, "General Preview Screen");   // pretty simple, just pass the report object and a preview caption


            if (this.optExport.Checked == true)  {
                // Use the method ExportReportToFile.....note that you can use the enumeration from the ccCrystalManager for the Export Type
                // There is also an overload, if you want to export a specific page range
                oCrystalManager.ExportReport(oReport, "c:\\mypdf.pdf", ccCrystalManager.ExportTypes.PDF, 1, 2);

                MessageBox.Show("Export completed");
            }


            if (this.optPrinter.Checked == true)
            {
                // easy one, just a straight print method
                oCrystalManager.PrintReport(oReport);
                MessageBox.Show("Print Completed!");
            }

            if (this.optPrinterPrompt.Checked == true)
            {
                // If you want to set specific print options, the library has a Print Options Form!
                ccCrystalPrintOptionForm oPrintOptionsForm = new ccCrystalPrintOptionForm();
                oPrintOptionsForm.ShowDialog();
                if (oPrintOptionsForm.DialogResult == DialogResult.OK)
                    oCrystalManager.PrintReport(oReport);
                
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.cboReportList.SelectedIndex = 0;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cboReportList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }





    }
}