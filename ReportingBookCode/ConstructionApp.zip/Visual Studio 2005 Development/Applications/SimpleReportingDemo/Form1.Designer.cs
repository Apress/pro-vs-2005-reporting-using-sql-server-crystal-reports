namespace SimpleReportingDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.optPreview = new System.Windows.Forms.RadioButton();
            this.optPrinter = new System.Windows.Forms.RadioButton();
            this.optPrinterPrompt = new System.Windows.Forms.RadioButton();
            this.optExport = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cboReportList = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnRun = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // optPreview
            // 
            this.optPreview.AutoSize = true;
            this.optPreview.Checked = true;
            this.optPreview.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optPreview.Location = new System.Drawing.Point(27, 82);
            this.optPreview.Name = "optPreview";
            this.optPreview.Size = new System.Drawing.Size(70, 17);
            this.optPreview.TabIndex = 1;
            this.optPreview.TabStop = true;
            this.optPreview.Text = "Preview";
            this.optPreview.UseVisualStyleBackColor = true;
            // 
            // optPrinter
            // 
            this.optPrinter.AutoSize = true;
            this.optPrinter.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optPrinter.Location = new System.Drawing.Point(27, 109);
            this.optPrinter.Name = "optPrinter";
            this.optPrinter.Size = new System.Drawing.Size(63, 17);
            this.optPrinter.TabIndex = 2;
            this.optPrinter.Text = "Printer";
            this.optPrinter.UseVisualStyleBackColor = true;
            // 
            // optPrinterPrompt
            // 
            this.optPrinterPrompt.AutoSize = true;
            this.optPrinterPrompt.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optPrinterPrompt.Location = new System.Drawing.Point(27, 136);
            this.optPrinterPrompt.Name = "optPrinterPrompt";
            this.optPrinterPrompt.Size = new System.Drawing.Size(137, 17);
            this.optPrinterPrompt.TabIndex = 3;
            this.optPrinterPrompt.Text = "Printer with Options";
            this.optPrinterPrompt.UseVisualStyleBackColor = true;
            // 
            // optExport
            // 
            this.optExport.AutoSize = true;
            this.optExport.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optExport.Location = new System.Drawing.Point(27, 163);
            this.optExport.Name = "optExport";
            this.optExport.Size = new System.Drawing.Size(62, 17);
            this.optExport.TabIndex = 4;
            this.optExport.Text = "Export";
            this.optExport.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(15, 62);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(151, 131);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Output Options";
            // 
            // cboReportList
            // 
            this.cboReportList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboReportList.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboReportList.FormattingEnabled = true;
            this.cboReportList.Items.AddRange(new object[] {
            "TimeSheet/Labor Report",
            "Gantt Chart",
            "Stacked Bar Chart",
            "Line/Pie Chart and Report",
            "Aging Report Summary"});
            this.cboReportList.Location = new System.Drawing.Point(9, 26);
            this.cboReportList.Name = "cboReportList";
            this.cboReportList.Size = new System.Drawing.Size(184, 21);
            this.cboReportList.TabIndex = 6;
            this.cboReportList.SelectedIndexChanged += new System.EventHandler(this.cboReportList_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Select Report";
            // 
            // btnRun
            // 
            this.btnRun.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnRun.Location = new System.Drawing.Point(353, 233);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(75, 23);
            this.btnRun.TabIndex = 8;
            this.btnRun.Text = "Run";
            this.btnRun.UseVisualStyleBackColor = false;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnClose.Location = new System.Drawing.Point(456, 233);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 9;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SimpleReportingDemo.Properties.Resources.Picture1;
            this.pictureBox2.Location = new System.Drawing.Point(372, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(164, 212);
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SimpleReportingDemo.Properties.Resources.bcm;
            this.pictureBox1.Location = new System.Drawing.Point(244, 53);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(120, 162);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(545, 267);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cboReportList);
            this.Controls.Add(this.optExport);
            this.Controls.Add(this.optPrinterPrompt);
            this.Controls.Add(this.optPrinter);
            this.Controls.Add(this.optPreview);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Output options";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton optPreview;
        private System.Windows.Forms.RadioButton optPrinter;
        private System.Windows.Forms.RadioButton optPrinterPrompt;
        private System.Windows.Forms.RadioButton optExport;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cboReportList;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

