using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using CGS.DataAccess;

namespace DeveloperUtilities
{
    public partial class FrmGenerateSchemas : Form
    {

        string cLocation = "c:\\MyXmlFiles\\";
        int nDBKey = 1;


        public FrmGenerateSchemas()
        {
            InitializeComponent();
        }

        private void btnGenerateSchema_Click(object sender, EventArgs e)
        {
            this.GenerateAgingSchema();
        }


        private void GenerateAgingSchema()
        {
            // Create Parms
            List<SqlParameter> oParms = new List<SqlParameter>();

            oParms.Add(new SqlParameter("@cCustomerList", "999"));
            oParms.Add(new SqlParameter("@dAgingDate", new DateTime(2006, 1, 1)));
            oParms.Add(new SqlParameter("@lShowDetails", true));

            // Call our form method, which calls the base CGS Data Access class
            DataSet dsReturn = this.GetResults("GetAgingReceivables", oParms);

            // Set the names, for both the set name and the table names

            dsReturn.DataSetName = "dsAgingReport";
            dsReturn.Tables[0].TableName = "dtAgingDetails";
            dsReturn.Tables[1].TableName = "dtAgingSummary";
            dsReturn.Tables[2].TableName = "dtAgingBrackets";
            dsReturn.Tables[3].TableName = "dtClients";

            dsReturn.AcceptChanges();

            string cXMLFile = cLocation + "dsAgingReport2.xsd";
//          dsReturn.WriteXml(cXMLFile, XmlWriteMode.WriteSchema);

            dsReturn.WriteXmlSchema(cXMLFile);

            MessageBox.Show(cXMLFile + " successfully created!");



        }


        private DataSet GetResults(string cStoredProc, List<SqlParameter> oParms)
        {

            cgsDataAccess oBaseData = new cgsDataAccess();
            DataSet dsReturn = new DataSet();
            return oBaseData.ReadIntoTypedDs(dsReturn, cStoredProc, oParms, nDBKey);

        }

        private void FrmGenerateSchemas_Load(object sender, EventArgs e)
        {

        }

    }
}