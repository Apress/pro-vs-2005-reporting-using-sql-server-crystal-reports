using System;
using System.Collections.Generic;
using System.Text;
using ConstructionDemo.Datasets;
using ConstructionDemo.DataAccess;
using CGS.Business;
using ConstructionDemo.Interfaces;

namespace ConstructionDemo.Business
{
    public class bzUser : cgsBaseBusinessObject, IUser< dsUser>
    {



        public enum UserStatus  { Active = 1, 
                                            TemporarilyInActive = 2, 
                                            Inactive = 3, 
                                            Suspended = 4, 
                                            Deleted = 5};





        public dsUser GetUser(string cUserID, string cPassword, int nDBKey) 
        {
            dsUser odsUser = new dsUser();
            odsUser = new daUser().GetUser(cUserID, cPassword, nDBKey);

            if (odsUser.dtUser.Rows.Count > 0)
            {
                dsUser.dtUserRow oRow = odsUser.dtUser[0];
                if (oRow.StatusFK != (int)UserStatus.Active)
                    oRow.Message = "Cannot login: User Status is currently " + oRow.StatusDescription.Trim();
                else
                    oRow.Message = String.Empty;
            }
            else
            {
                dsUser.dtUserRow oBlankRow = odsUser.dtUser.NewdtUserRow();
                oBlankRow.Message = "User ID/Password was not found";
                odsUser.dtUser.AdddtUserRow(oBlankRow);
            }


            return odsUser;

        }
    }
}
