using System;
using System.Collections.Generic;
using System.Text;
using ConstructionDemo.Datasets;
using ConstructionDemo.DataAccess;
using ConstructionDemo.Interfaces;
using CGS.Business;

namespace ConstructionDemo.Business
{
    public class bzJobSummary: cgsBaseBusinessObject //, IJobSummary<dsJobSummary>
    {


//        public dsJobSummary GetJobSummary(string cJobList, int nDBKey)
  //      {
    //        return new daJobSummary().GetJobSummary(cJobList, nDBKey);
      //  }


    }
}
