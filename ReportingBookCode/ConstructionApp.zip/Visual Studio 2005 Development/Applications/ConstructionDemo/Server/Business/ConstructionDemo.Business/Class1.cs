using System;
using System.Collections.Generic;
using System.Text;

namespace ConstructionDemo.Business
{
    public class Class1
    {
    }
}
