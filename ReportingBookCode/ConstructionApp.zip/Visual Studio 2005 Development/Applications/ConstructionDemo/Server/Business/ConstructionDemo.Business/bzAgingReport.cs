using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using ConstructionDemo.Datasets;
using ConstructionDemo.DataAccess;
using CGS.Business;

using ConstructionDemo.Interfaces;

namespace ConstructionDemo.Business
{
    public class bzAgingReport : cgsBaseBusinessObject, IAgingReport<dsAgingReport>
    {
        public dsAgingReport GetAgingReport(DateTime dAsOfDate, bool lDetails, string cClientList, int nDBKey)
        {
            dsAgingReport odsAgingReport = new dsAgingReport();
            odsAgingReport = new daAgingReport().GetAgingReport(dAsOfDate, lDetails, cClientList, nDBKey);

            string[] Brackets = new string[5];

            for(int nRowCtr=0;nRowCtr<5;nRowCtr++)
                Brackets[nRowCtr] = odsAgingReport.dtAgingBrackets[nRowCtr].BracketLabel;

            odsAgingReport.dtBracketColumns.AdddtBracketColumnsRow(Brackets[0],Brackets[1],Brackets[2],Brackets[3],Brackets[4]);
            return odsAgingReport;
            
       }
    }
}
