using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using ConstructionDemo.Business;


namespace ConstructionDemo.RemotingServer
{
    public partial class frmListener : Form
    {
        public frmListener()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void btnLaunch_Click(object sender, EventArgs e)
        {
            TcpServerChannel Tcps;
            int nTCPPort = 8228;    // for demo purposes, would normally come out of a config file

            Tcps = new TcpServerChannel(nTCPPort);
            ChannelServices.RegisterChannel(Tcps);    // register the channel 

            // Create a listener � client code can activate object with the same type, using the 
            // port number and server address
            RemotingConfiguration.RegisterWellKnownServiceType(
                typeof(bzAgingReport),
            "bzAgingReport", WellKnownObjectMode.Singleton);

            RemotingConfiguration.RegisterWellKnownServiceType( 
                typeof(bzUser),  
                "bzUser", WellKnownObjectMode.Singleton);

        }
    }
}