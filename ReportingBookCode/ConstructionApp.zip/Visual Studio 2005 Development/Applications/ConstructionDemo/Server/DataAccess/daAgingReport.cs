using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using MyApplication.MyDataAccess;

using CGS.DataAccess;
using ConstructionDemo.Datasets;



namespace ConstructionDemo.DataAccess
{
    public class daAgingReport :  CGS.DataAccess.cgsDataAccess 
    {

//        public DataSet GetAgingReportData(DateTime dAsOfDate, bool lDetails, string cClientList)
  //      {
    //        DataSet dsResults = new DataSet();

      //      string cSPName = "[dbo].[GetAgingReceivables]"; 

//            List<SqlParameter> oParms = new List<SqlParameter>();

//            oParms.Add(new SqlParameter("@cCustomerList", cClientList));
//            oParms.Add(new SqlParameter("@dAgingDate", dAsOfDate));
//            oParms.Add(new SqlParameter("@lShowDetails", lDetails));
         
//          dsResults = this.RetrieveFromSP(cSPName,oParms,100);/


//            return dsResults;

//        }




        public dsAgingReport GetAgingReport(DateTime dAsOfDate, bool lDetails, string cClientList, int nDBKey)
        {

            List<SqlParameter> oParms = new List<SqlParameter>();

            oParms.Add(new SqlParameter("@cCustomerList", cClientList));
            oParms.Add(new SqlParameter("@dAgingDate", dAsOfDate));
            oParms.Add(new SqlParameter("@lShowDetails", lDetails));

            // we can have a base data access class read the results of a stored procedure 
            // DIRECTLY into a typed dataset....no need to do a MERGE
            dsAgingReport odsAgingReport = new dsAgingReport();
            odsAgingReport =this.ReadIntoTypedDs(odsAgingReport, "[dbo].[GetAgingReceivables]", oParms,nDBKey);

            return odsAgingReport;

        }
    }

}
