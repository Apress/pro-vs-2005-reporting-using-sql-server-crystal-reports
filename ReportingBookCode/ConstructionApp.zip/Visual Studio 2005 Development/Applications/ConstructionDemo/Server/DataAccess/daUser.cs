using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using CGS.DataAccess;
using ConstructionDemo.Datasets;


namespace ConstructionDemo.DataAccess
{
    public class daUser : cgsDataAccess
    {

        public dsUser GetUser(string cUserID, string cPassword, int nDBKey)
        {

            List<SqlParameter> oParms = new List<SqlParameter>();

            oParms.Add(new SqlParameter("@cUserID", cUserID));
            oParms.Add(new SqlParameter("@cPassword", cPassword));

            dsUser odsUser = new dsUser(); 
            odsUser =  this.ReadIntoTypedDs(odsUser, "[dbo].[ValidateUserID]", oParms, nDBKey);

            return odsUser;

        }
    }

}