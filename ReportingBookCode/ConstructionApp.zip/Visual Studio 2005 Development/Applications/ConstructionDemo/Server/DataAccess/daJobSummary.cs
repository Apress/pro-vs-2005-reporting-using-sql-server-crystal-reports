using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using CGS.DataAccess;
using ConstructionDemo.Datasets;



namespace ConstructionDemo.DataAccess
{
    public class daJobSummary : cgsDataAccess
    {


//        public  dsJobSummary GetJobSummary(string cJobList, int nDBKey)
  //      {

    //        List<SqlParameter> oParms = new List<SqlParameter>();

      //      oParms.Add(new SqlParameter("@cJobList", ""));

        //    dsJobSummary odsJobSummary = new dsJobSummary();
          //  odsJobSummary= this.ReadIntoTypedDs(odsJobSummary, "[dbo].[GetJobSummaries]", oParms,nDBKey);

            //return odsJobSummary;


       // }
    }

}
