using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using CGS.DataAccess;
using ConstructionDemo.Datasets;



namespace ConstructionDemo.DataAccess
{
    public class daConstructionDemoAgingReport : cgsDataAccess
    {


        public dsAgingReport GetAgingReport(DateTime dAsOfDate, bool lDetails, string cClientList, int nDBKey)
        {

            List<SqlParameter> oParms = new List<SqlParameter>();

            oParms.Add(new SqlParameter("@cCustomerList", ""));
            oParms.Add(new SqlParameter("@dAgingDate", DateTime.Today));
            oParms.Add(new SqlParameter("@lShowDetails", true));

            // we can have a base data access class read the results of a stored procedure 
            // DIRECTLY into a typed dataset....no need to do a MERGE
            dsAgingReport odsAgingReport = new dsAgingReport();
            odsAgingReport = this.RetrieveDataIntoTypedDs(odsAgingReport, "[dbo].[GetAgingReceivables]", oParms);

            return odsAgingReport;


        }
    }

}
