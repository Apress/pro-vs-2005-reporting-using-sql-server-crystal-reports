using System;
using System.Collections.Generic;
using System.Text;

namespace ConstructionDemo.DataAccess
{
    public class daConstructionDemoAgingReport : ConstructionDemo.DataAccess
    {
    }
}
