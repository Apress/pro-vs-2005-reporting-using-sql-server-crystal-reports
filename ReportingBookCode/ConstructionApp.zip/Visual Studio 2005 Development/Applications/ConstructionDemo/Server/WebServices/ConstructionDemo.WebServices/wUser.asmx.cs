using System;
using System.Data;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;
using ConstructionDemo.Interfaces;
using ConstructionDemo.Business;



namespace ConstructionDemo.WebServices
{
    /// <summary>
    /// Summary description for wUser
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    public class wUser : System.Web.Services.WebService, IUser<string>
    {
        [WebMethod]
        public string GetUser(string cUserID, string cPassword, int nDBKey)
        {
//            SqlConnection oconn = new SqlConnection();
  //          oconn.ConnectionString = "server=KCI890;trusted_connection=true;password=;Initial Catalog=constructiondemo";
    //        oconn.Open();



            string cXML = new bzUser().GetUser(cUserID, cPassword, nDBKey).GetXml(); 

            return cXML;

        }
    }
}
