using System;
using System.Data;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;
using ConstructionDemo.Interfaces;
using ConstructionDemo.Business;


namespace ConstructionDemo.WebServices
{
    /// <summary>
    /// Summary description for wAgingReport
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    public class wAgingReport : System.Web.Services.WebService,  IAgingReport<string>
    {

        [WebMethod]
        public string GetAgingReport(DateTime dAsOfDate, bool lDetails, string cClientList, int nDBKey) 
        {

            string cXML = new bzAgingReport().GetAgingReport(dAsOfDate, lDetails, cClientList, nDBKey).GetXml();

            return cXML;

        }
    }
}
