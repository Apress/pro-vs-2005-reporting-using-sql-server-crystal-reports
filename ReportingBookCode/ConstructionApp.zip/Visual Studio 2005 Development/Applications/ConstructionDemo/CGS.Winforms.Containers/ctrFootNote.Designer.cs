namespace CGS.Winforms.Containers
{
    partial class ctrFootNote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cgsLabel1 = new CGS.Winforms.Controls.cgsLabel();
            this.txtFootNote = new CGS.Winforms.Controls.cgsMaskedTextBox();
            this.cgsPanel1 = new CGS.Winforms.Controls.cgsPanel();
            this.cgsPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cgsLabel1
            // 
            this.cgsLabel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cgsLabel1.AutoSize = true;
            this.cgsLabel1.Font = new System.Drawing.Font("Verdana", 8F);
            this.cgsLabel1.Location = new System.Drawing.Point(196, 13);
            this.cgsLabel1.Name = "cgsLabel1";
            this.cgsLabel1.Size = new System.Drawing.Size(127, 13);
            this.cgsLabel1.TabIndex = 0;
            this.cgsLabel1.Text = "Enter report footnote";
            // 
            // txtFootNote
            // 
            this.txtFootNote.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFootNote.Font = new System.Drawing.Font("Verdana", 8F);
            this.txtFootNote.Location = new System.Drawing.Point(6, 36);
            this.txtFootNote.Name = "txtFootNote";
            this.txtFootNote.Size = new System.Drawing.Size(508, 20);
            this.txtFootNote.TabIndex = 1;
            // 
            // cgsPanel1
            // 
            this.cgsPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cgsPanel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.cgsPanel1.Controls.Add(this.txtFootNote);
            this.cgsPanel1.Controls.Add(this.cgsLabel1);
            this.cgsPanel1.Location = new System.Drawing.Point(15, 11);
            this.cgsPanel1.Name = "cgsPanel1";
            this.cgsPanel1.Size = new System.Drawing.Size(523, 70);
            this.cgsPanel1.TabIndex = 2;
            // 
            // ctrFootNote
            // 
            this.Controls.Add(this.cgsPanel1);
            this.Name = "ctrFootNote";
            this.Size = new System.Drawing.Size(553, 92);
            this.cgsPanel1.ResumeLayout(false);
            this.cgsPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private CGS.Winforms.Controls.cgsLabel cgsLabel1;
        public CGS.Winforms.Controls.cgsMaskedTextBox txtFootNote;
        private CGS.Winforms.Controls.cgsPanel cgsPanel1;
    }
}
