namespace CGS.Winforms.Containers
{
    partial class ctrRecordSelect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ctrRecordSelect));
            this.grdSelect = new CGS.Winforms.Controls.cgsGrid();
            this.txtSearch = new CGS.Winforms.Controls.cgsMaskedTextBox();
            this.btnFind = new CGS.Winforms.Controls.cgsButton();
            this.btnFindNext = new CGS.Winforms.Controls.cgsButton();
            this.cgsLabel1 = new CGS.Winforms.Controls.cgsLabel();
            this.btnFilter = new CGS.Winforms.Controls.cgsButton();
            this.lblSelected = new CGS.Winforms.Controls.cgsLabel();
            this.chkSelectAll = new CGS.Winforms.Controls.cgsButton();
            this.chkUnselectAll = new CGS.Winforms.Controls.cgsButton();
            this.lblTotalItems = new CGS.Winforms.Controls.cgsLabel();
            this.cgsPanel1 = new CGS.Winforms.Controls.cgsPanel();
            ((System.ComponentModel.ISupportInitialize)(this.grdSelect)).BeginInit();
            this.cgsPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // grdSelect
            // 
            this.grdSelect.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grdSelect.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdSelect.Location = new System.Drawing.Point(14, 92);
            this.grdSelect.Name = "grdSelect";
            this.grdSelect.RowHeadersWidth = 10;
            this.grdSelect.Size = new System.Drawing.Size(506, 196);
            this.grdSelect.TabIndex = 0;
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Verdana", 8F);
            this.txtSearch.Location = new System.Drawing.Point(14, 29);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(373, 20);
            this.txtSearch.TabIndex = 1;
            // 
            // btnFind
            // 
            this.btnFind.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFind.BackColor = System.Drawing.Color.White;
            this.btnFind.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnFind.Image = ((System.Drawing.Image)(resources.GetObject("btnFind.Image")));
            this.btnFind.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFind.Location = new System.Drawing.Point(423, 13);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(97, 23);
            this.btnFind.TabIndex = 2;
            this.btnFind.Text = "Find";
            this.btnFind.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFind.UseVisualStyleBackColor = true;
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // btnFindNext
            // 
            this.btnFindNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFindNext.BackColor = System.Drawing.Color.White;
            this.btnFindNext.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnFindNext.Image = ((System.Drawing.Image)(resources.GetObject("btnFindNext.Image")));
            this.btnFindNext.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFindNext.Location = new System.Drawing.Point(423, 37);
            this.btnFindNext.Name = "btnFindNext";
            this.btnFindNext.Size = new System.Drawing.Size(97, 23);
            this.btnFindNext.TabIndex = 3;
            this.btnFindNext.Text = "Find Next";
            this.btnFindNext.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFindNext.UseVisualStyleBackColor = true;
            this.btnFindNext.Click += new System.EventHandler(this.btnFindNext_Click);
            // 
            // cgsLabel1
            // 
            this.cgsLabel1.AutoSize = true;
            this.cgsLabel1.Font = new System.Drawing.Font("Verdana", 8F);
            this.cgsLabel1.Location = new System.Drawing.Point(11, 13);
            this.cgsLabel1.Name = "cgsLabel1";
            this.cgsLabel1.Size = new System.Drawing.Size(59, 13);
            this.cgsLabel1.TabIndex = 4;
            this.cgsLabel1.Text = "Find Text";
            // 
            // btnFilter
            // 
            this.btnFilter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFilter.BackColor = System.Drawing.Color.White;
            this.btnFilter.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnFilter.Image = ((System.Drawing.Image)(resources.GetObject("btnFilter.Image")));
            this.btnFilter.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFilter.Location = new System.Drawing.Point(423, 61);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new System.Drawing.Size(97, 23);
            this.btnFilter.TabIndex = 5;
            this.btnFilter.Text = "Filter";
            this.btnFilter.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFilter.UseVisualStyleBackColor = true;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // lblSelected
            // 
            this.lblSelected.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSelected.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold);
            this.lblSelected.Location = new System.Drawing.Point(8, 285);
            this.lblSelected.Name = "lblSelected";
            this.lblSelected.Size = new System.Drawing.Size(195, 13);
            this.lblSelected.TabIndex = 6;
            this.lblSelected.Text = "0 selected";
            this.lblSelected.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // chkSelectAll
            // 
            this.chkSelectAll.BackColor = System.Drawing.Color.White;
            this.chkSelectAll.Font = new System.Drawing.Font("Verdana", 8F);
            this.chkSelectAll.Image = ((System.Drawing.Image)(resources.GetObject("chkSelectAll.Image")));
            this.chkSelectAll.Location = new System.Drawing.Point(14, 64);
            this.chkSelectAll.Name = "chkSelectAll";
            this.chkSelectAll.Size = new System.Drawing.Size(25, 23);
            this.chkSelectAll.TabIndex = 7;
            this.chkSelectAll.UseVisualStyleBackColor = true;
            this.chkSelectAll.Click += new System.EventHandler(this.chkSelectAll_Click);
            // 
            // chkUnselectAll
            // 
            this.chkUnselectAll.BackColor = System.Drawing.Color.White;
            this.chkUnselectAll.Font = new System.Drawing.Font("Verdana", 8F);
            this.chkUnselectAll.Image = ((System.Drawing.Image)(resources.GetObject("chkUnselectAll.Image")));
            this.chkUnselectAll.Location = new System.Drawing.Point(45, 64);
            this.chkUnselectAll.Name = "chkUnselectAll";
            this.chkUnselectAll.Size = new System.Drawing.Size(25, 23);
            this.chkUnselectAll.TabIndex = 8;
            this.chkUnselectAll.UseVisualStyleBackColor = true;
            this.chkUnselectAll.Click += new System.EventHandler(this.chkUnselectAll_Click);
            // 
            // lblTotalItems
            // 
            this.lblTotalItems.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTotalItems.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold);
            this.lblTotalItems.Location = new System.Drawing.Point(317, 285);
            this.lblTotalItems.Name = "lblTotalItems";
            this.lblTotalItems.Size = new System.Drawing.Size(195, 13);
            this.lblTotalItems.TabIndex = 9;
            this.lblTotalItems.Text = "0 available";
            this.lblTotalItems.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cgsPanel1
            // 
            this.cgsPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cgsPanel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.cgsPanel1.Controls.Add(this.lblTotalItems);
            this.cgsPanel1.Controls.Add(this.lblSelected);
            this.cgsPanel1.Location = new System.Drawing.Point(6, 7);
            this.cgsPanel1.Name = "cgsPanel1";
            this.cgsPanel1.Size = new System.Drawing.Size(526, 308);
            this.cgsPanel1.TabIndex = 10;
            this.cgsPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.cgsPanel1_Paint);
            // 
            // ctrRecordSelect
            // 
            this.Controls.Add(this.chkUnselectAll);
            this.Controls.Add(this.chkSelectAll);
            this.Controls.Add(this.btnFilter);
            this.Controls.Add(this.cgsLabel1);
            this.Controls.Add(this.btnFindNext);
            this.Controls.Add(this.btnFind);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.grdSelect);
            this.Controls.Add(this.cgsPanel1);
            this.Name = "ctrRecordSelect";
            this.Size = new System.Drawing.Size(535, 328);
            this.Enter += new System.EventHandler(this.ctrRecordSelect_Enter);
            this.Load += new System.EventHandler(this.ctrRecordSelect_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grdSelect)).EndInit();
            this.cgsPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CGS.Winforms.Controls.cgsGrid grdSelect;
        private CGS.Winforms.Controls.cgsMaskedTextBox txtSearch;
        private CGS.Winforms.Controls.cgsButton btnFind;
        private CGS.Winforms.Controls.cgsButton btnFindNext;
        private CGS.Winforms.Controls.cgsLabel cgsLabel1;
        private CGS.Winforms.Controls.cgsButton btnFilter;
        private CGS.Winforms.Controls.cgsLabel lblSelected;
        private CGS.Winforms.Controls.cgsButton chkSelectAll;
        private CGS.Winforms.Controls.cgsButton chkUnselectAll;
        private CGS.Winforms.Controls.cgsLabel lblTotalItems;
        private CGS.Winforms.Controls.cgsPanel cgsPanel1;
    }
}
