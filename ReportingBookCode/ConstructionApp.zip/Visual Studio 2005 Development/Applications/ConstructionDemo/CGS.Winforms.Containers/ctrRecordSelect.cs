using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CGS.Winforms.Containers
{
    public partial class ctrRecordSelect : CGS.Winforms.Controls.cgsContainer
    {

        private bool lFilterOn = false;

        private DataTable _dtSource;
        public DataTable dtSource
        {

           get { return _dtSource; }
            set { _dtSource = value; }
        }



        private string _SelectColumn ;
        public string SelectColumn
        {

            get { return _SelectColumn; }
            set { _SelectColumn = value; }
        }


        private string _DescriptionColumn ;
        public string DescriptionColumn
        {

            get { return _DescriptionColumn; }
            set { _DescriptionColumn = value; }
        }


        private string _PKColumn;
        public string PKColumn
        {

            get { return _PKColumn; }
            set { _PKColumn = value; }
        }


        private string _PKList;
        public string PKList
        {

            get { return _PKList; }
            set { _PKList = value; }
        }


        public ctrRecordSelect()
        {
            InitializeComponent();
        }

        private void ctrRecordSelect_Load(object sender, EventArgs e)
        {

        }


        private void CheckFilterChanged(object sender, DataColumnChangeEventArgs e)
        {
            this.SetCount();
        }





        private void ctrRecordSelect_Enter(object sender, EventArgs e)
        {
            this.dtSource.DefaultView.AllowNew = false;
           
            this.grdSelect.DataSource = this.dtSource.DefaultView;
            this.grdSelect.CellContentClick += new DataGridViewCellEventHandler(grdSelect_CellContentClick);

            foreach (DataColumn dc in this.dtSource.Columns)
            {
                try
                {
                    this.grdSelect.Columns.Remove(dc.ColumnName.ToString());
                }
                catch (Exception)
                {
                }
            }

               

            DataGridViewCheckBoxColumn fld1 = new DataGridViewCheckBoxColumn();
            fld1.DataPropertyName =  this.SelectColumn;
            fld1.HeaderText = "Selected";
            fld1.Width = 55;
            fld1.ReadOnly = false;
            this.grdSelect.Columns.Insert(0, fld1);

            DataGridViewTextBoxColumn fld2 = new DataGridViewTextBoxColumn();
            fld2.DataPropertyName = this.DescriptionColumn;
            fld2.HeaderText = "Description";
            fld2.Width = this.grdSelect.Width - fld1.Width - 11;
            fld2.ReadOnly = true;
            this.grdSelect.Columns.Insert(1, fld2);

            this.SetCount();
        }



        void grdSelect_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            this.grdSelect.CommitEdit(DataGridViewDataErrorContexts.Commit);
            this.SetCount();
         
        }


        
        private void MarkAll(bool lMark)
        {
            foreach (DataRow dr in this.dtSource.Rows)
                dr[this.SelectColumn] = lMark;
            this.SetCount();
        }



        private void chkSelectAll_Click(object sender, EventArgs e)
        {
            this.MarkAll(true);


        }

        private void chkUnselectAll_Click(object sender, EventArgs e)
        {
            this.MarkAll(false);
        }


        private void SetCount()
        {
            this.lblTotalItems.Text = this.dtSource.DefaultView.Count.ToString().Trim() + " Total item(s)";
            
            string cFilter = this.SelectColumn + " = true ";

            DataRow[] drSelections =  this.dtSource.DefaultView.ToTable().Select(cFilter);

            int nCount = drSelections.Length;
            this.lblSelected.Text = nCount.ToString().Trim() + " item(s) selected";

            this.PKList = String.Empty;
            foreach (DataRow dr in drSelections)
                this.PKList += dr[this.PKColumn].ToString().Trim() + ",";

            if (this.PKList != String.Empty)
                this.PKList = this.PKList.Substring(0, this.PKList.Length - 1);

        }


        private void btnFilter_Click(object sender, EventArgs e)
        {
            this.FilterList();
        }
        

        private void TextSearch(bool lStartAtTop)
        {
            BindingManagerBase bMgr = this.grdSelect.BindingContext[this.grdSelect.DataSource,this.grdSelect.DataMember];
            
			// Will scan through rows and columns (and will respect the column scope list) for a hit
			int nStartRow;
			bool lFound = false;

			int nRowCount = bMgr.Count; 

			string cSearchText = this.txtSearch.Text.ToString().Trim();
            if (cSearchText.Length > 0)
            {
                int nPos = bMgr.Position;
                if (lStartAtTop == true)
                    nStartRow = 0;
                else
                    nStartRow = bMgr.Position + 1;

                int nRowCtr;
                for (nRowCtr = nStartRow; nRowCtr < nRowCount; nRowCtr++)     // scan through all rows (or starting at current row + 1)
                {
                    if (this.dtSource.DefaultView[nRowCtr][this.DescriptionColumn].ToString().IndexOf(cSearchText) >= 0)
                    {
                        bMgr.Position = nRowCtr;
                        lFound = true;
                        break;
                    }
                }

                if (lFound == false)
                    MessageBox.Show("End of the result list reached!");
            }

		}
 

        private void FilterList()
        {
            if (this.lFilterOn == false)
            {
                this.btnFilter.Text = "Filter Off";
                string cFilter = this.DescriptionColumn + " Like '%" + this.txtSearch.Text.ToString().Trim() + "%'";
                this.dtSource.DefaultView.RowFilter = cFilter;
            
            }
            else
            {
                this.btnFilter.Text = "Filter On";
                this.dtSource.DefaultView.RowFilter = "";
            }

            this.lFilterOn = !this.lFilterOn;
            this.SetCount();
        }


        private void btnFind_Click(object sender, EventArgs e)
        {
            this.TextSearch(true);
        }

        private void btnFindNext_Click(object sender, EventArgs e)
        {
            this.TextSearch(false);
        }

        private void cgsPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

  
    }
}

