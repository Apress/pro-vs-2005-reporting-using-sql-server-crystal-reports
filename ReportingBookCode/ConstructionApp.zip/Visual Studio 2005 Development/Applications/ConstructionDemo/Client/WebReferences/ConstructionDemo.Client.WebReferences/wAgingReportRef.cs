// wAgingReportRef.cs
// Subclasses the Web Service reference, to implement IAgingReport
using System;
using System.Collections.Generic;
using System.Text;
using ConstructionDemo.Interfaces;


namespace ConstructionDemo.Client.WebReferences
{
    public class wAgingReportRef : wAgingReport.wAgingReport, IAgingReport<string>
    {

    }
}
