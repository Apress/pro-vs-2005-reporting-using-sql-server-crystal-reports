using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CGS.Globals;
using System.Management;


namespace ConstructionDemo.Client.Winforms
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            this.SetStatus();

        }


        private void SetStatus()
        {
            cgsGlobals oGlobals = new cgsGlobals();

            // Show the user and connection
            this.toolStripStatusLblUser.Text = "User: " +  oGlobals.cUserName;
            this.toolStripStatusLblConnection.Text = "Connection: " +   oGlobals.cCurrentConnection ;

            // Now calculate the amount of free disk space

            // If the local drive is not the 'C' drive, you'd need to determine it
            ManagementObject disk = new ManagementObject("win32_logicaldisk.deviceid='c:'");
            
            disk.Get();
            long availFree = long.Parse(disk["Freespace"].ToString());
            string cMessage = "";

            // If we have at least 1 GB left, show in terms of GB
            if(availFree > 1000000000)
            {
            	decimal nGB =  System.Math.Round((decimal)(availFree / 1000000000.00),2);
            	cMessage = nGB.ToString().Trim() + " GB";
            }
            else
            // Show in terms of MB
            {
                decimal nMB = System.Math.Round((decimal)(availFree / 1000000.00), 2);
                cMessage = nMB.ToString().Trim() + " MB";
            }

            this.toolStripStatusLblDiskSpace.Text = "Available disk space: "  + cMessage;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            FrmReportLauncher oFrmReportLauncher = new FrmReportLauncher();
            oFrmReportLauncher.ShowDialog();
        }


    }
}