using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ConstructionDemo.Datasets;
using System.IO;

namespace ConstructionDemo.Client.Winforms
{
    public partial class FrmAgingReport : CGS.Winforms.Forms.cgsFrmApplication
    {
        public FrmAgingReport()
        {
            InitializeComponent();
        }

        private void FrmAgingReport_Load(object sender, EventArgs e)
        {
            DataTable dtClients = new DataTable();

            dtClients.Columns.Add("Selected", typeof(System.Boolean));
            dtClients.Columns.Add("ClientPK", typeof(System.Int32));
            dtClients.Columns.Add("ClientName", typeof(System.String));

            dtClients.Rows.Add(false, 1, "KINGSTON CONSTRUCTION");
            dtClients.Rows.Add(false, 2, "GOLDGATE CONTRACTING");
            dtClients.Rows.Add(false, 3, "L& L EXCAVATING INC.");
            dtClients.Rows.Add(false, 4, "ROBINSKY HOUSING");

            this.ctrAgingRecordSelect.dtSource = dtClients;
            this.ctrAgingRecordSelect.DescriptionColumn = "ClientName";
            this.ctrAgingRecordSelect.SelectColumn = "Selected";
            this.ctrAgingRecordSelect.PKColumn = "ClientPK";


  
        }

        private void ctrRecordSelect1_Load(object sender, EventArgs e)
        {

        }

        private void cgsButton2_Click(object sender, EventArgs e)
        {

        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            this.SetMessageOn("Running Report...please wait");

     
            FrmAgingReportManager oAgingClass = new FrmAgingReportManager();

            oAgingClass.cClientList = this.ctrAgingRecordSelect.PKList;
            oAgingClass.cFootNote = this.ctrAgingFootNote.txtFootNote.Text.ToString().Trim();
            oAgingClass.dAgingDate =  this.dAgingDate.Value;
            oAgingClass.lDetails = this.chkDetails.Checked;;

            oAgingClass.RunAgingReport();

            this.SetMessageOff();


        }
    }
}

