using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;





namespace ConstructionDemo.Client.Winforms
{
    public partial class FrmGenerateSchemas : Form
    {

        string cLocation = "c:\\MyXmlFiles2\\";
        int nDBKey = 1;

        public FrmGenerateSchemas()
        {
            InitializeComponent();
        }

        private void FrmGenerateSchemas_Load(object sender, EventArgs e)
        {

        }

        private void btnGenerateSchema_Click(object sender, EventArgs e)
        {
            this.GenerateAgingSchema();
        }


        private void GenerateAgingSchema()
        {
            // Create Parms
//            List<SqlParameter> oParms = new List<SqlParameter>();

  //          oParms.Add(new SqlParameter("@cCustomerList", "1"));
    //        oParms.Add(new SqlParameter("@dAgingDate", new DateTime(2006,1,1)));
      //      oParms.Add(new SqlParameter("@lShowDetails", true));

            // Call our form method, which calls the base CGS Data Access class
//            DataSet dsReturn = this.GetResults("GetAgingReceivables",oParms);

            // Set the names
  //          dsReturn.DataSetName = "dsAgingReport";
    //        dsReturn.Tables[0].TableName = "dtAgingDetails";
      //      dsReturn.Tables[1].TableName = "dtAgingSummary";
        //    dsReturn.Tables[2].TableName = "dtAgingBrackets";
          //  dsReturn.Tables[3].TableName = "dtClients";

//            string cXMLFile = cLocation + "dsAgingReport.Xsd";
  //          dsReturn.WriteXml(cXMLFile,XmlWriteMode.WriteSchema);



        }


//        private DataSet GetResults(string cStoredProc, List<SqlParameter> oParms)
  //      {

//            cgsDataAccess oBaseData = new cgsDataAccess();
  //          DataSet dsReturn = new DataSet();
    //        return oBaseData.ReadIntoTypedDs(dsReturn, cStoredProc, oParms,nDBKey);

    //    }


    }
}