namespace ConstructionDemo.Client.Winforms
{
    partial class FrmAgingReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrAgingRecordSelect = new CGS.Winforms.Containers.ctrRecordSelect();
            this.cgsPanel1 = new CGS.Winforms.Controls.cgsPanel();
            this.chkDetails = new CGS.Winforms.Controls.cgsCheckBox();
            this.dAgingDate = new CGS.Winforms.Controls.cgsDateTime();
            this.cgsLabel1 = new CGS.Winforms.Controls.cgsLabel();
            this.ctrAgingFootNote = new CGS.Winforms.Containers.ctrFootNote();
            this.btnRun = new CGS.Winforms.Controls.cgsButton();
            this.btnClose = new CGS.Winforms.Controls.cgsButton();
            this.cgsPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ctrAgingRecordSelect
            // 
            this.ctrAgingRecordSelect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ctrAgingRecordSelect.DescriptionColumn = null;
            this.ctrAgingRecordSelect.dtSource = null;
            this.ctrAgingRecordSelect.Location = new System.Drawing.Point(11, 119);
            this.ctrAgingRecordSelect.Name = "ctrAgingRecordSelect";
            this.ctrAgingRecordSelect.PKColumn = null;
            this.ctrAgingRecordSelect.PKList = null;
            this.ctrAgingRecordSelect.SelectColumn = null;
            this.ctrAgingRecordSelect.Size = new System.Drawing.Size(535, 282);
            this.ctrAgingRecordSelect.TabIndex = 1;
            // 
            // cgsPanel1
            // 
            this.cgsPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cgsPanel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.cgsPanel1.Controls.Add(this.chkDetails);
            this.cgsPanel1.Controls.Add(this.dAgingDate);
            this.cgsPanel1.Controls.Add(this.cgsLabel1);
            this.cgsPanel1.Location = new System.Drawing.Point(17, 9);
            this.cgsPanel1.Name = "cgsPanel1";
            this.cgsPanel1.Size = new System.Drawing.Size(233, 76);
            this.cgsPanel1.TabIndex = 3;
            // 
            // chkDetails
            // 
            this.chkDetails.AutoSize = true;
            this.chkDetails.Font = new System.Drawing.Font("Verdana", 8F);
            this.chkDetails.Location = new System.Drawing.Point(41, 46);
            this.chkDetails.Name = "chkDetails";
            this.chkDetails.Size = new System.Drawing.Size(157, 17);
            this.chkDetails.TabIndex = 2;
            this.chkDetails.Text = "Include Invoice Details";
            this.chkDetails.UseVisualStyleBackColor = true;
            // 
            // dAgingDate
            // 
            this.dAgingDate.Font = new System.Drawing.Font("Verdana", 8F);
            this.dAgingDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dAgingDate.Location = new System.Drawing.Point(120, 6);
            this.dAgingDate.Name = "dAgingDate";
            this.dAgingDate.Size = new System.Drawing.Size(92, 20);
            this.dAgingDate.TabIndex = 1;
            // 
            // cgsLabel1
            // 
            this.cgsLabel1.AutoSize = true;
            this.cgsLabel1.Font = new System.Drawing.Font("Verdana", 8F);
            this.cgsLabel1.Location = new System.Drawing.Point(4, 10);
            this.cgsLabel1.Name = "cgsLabel1";
            this.cgsLabel1.Size = new System.Drawing.Size(104, 13);
            this.cgsLabel1.TabIndex = 0;
            this.cgsLabel1.Text = "Enter Aging Date";
            // 
            // ctrAgingFootNote
            // 
            this.ctrAgingFootNote.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ctrAgingFootNote.Location = new System.Drawing.Point(2, 405);
            this.ctrAgingFootNote.Name = "ctrAgingFootNote";
            this.ctrAgingFootNote.Size = new System.Drawing.Size(553, 92);
            this.ctrAgingFootNote.TabIndex = 4;
            // 
            // btnRun
            // 
            this.btnRun.BackColor = System.Drawing.Color.White;
            this.btnRun.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnRun.Location = new System.Drawing.Point(360, 504);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(75, 23);
            this.btnRun.TabIndex = 5;
            this.btnRun.Text = "Run";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnClose.Location = new System.Drawing.Point(461, 504);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.cgsButton2_Click);
            // 
            // FrmAgingReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(556, 556);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.ctrAgingFootNote);
            this.Controls.Add(this.cgsPanel1);
            this.Controls.Add(this.ctrAgingRecordSelect);
            this.Name = "FrmAgingReport";
            this.Text = "Aging Receivables Report";
            this.Load += new System.EventHandler(this.FrmAgingReport_Load);
            this.Controls.SetChildIndex(this.ctrAgingRecordSelect, 0);
            this.Controls.SetChildIndex(this.cgsPanel1, 0);
            this.Controls.SetChildIndex(this.ctrAgingFootNote, 0);
            this.Controls.SetChildIndex(this.btnRun, 0);
            this.Controls.SetChildIndex(this.btnClose, 0);
            this.cgsPanel1.ResumeLayout(false);
            this.cgsPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private CGS.Winforms.Containers.ctrRecordSelect ctrAgingRecordSelect;
        private CGS.Winforms.Controls.cgsPanel cgsPanel1;
        private CGS.Winforms.Controls.cgsCheckBox chkDetails;
        private CGS.Winforms.Controls.cgsDateTime dAgingDate;
        private CGS.Winforms.Controls.cgsLabel cgsLabel1;
        private CGS.Winforms.Containers.ctrFootNote ctrAgingFootNote;
        private CGS.Winforms.Controls.cgsButton btnRun;
        private CGS.Winforms.Controls.cgsButton btnClose;


    }
}
