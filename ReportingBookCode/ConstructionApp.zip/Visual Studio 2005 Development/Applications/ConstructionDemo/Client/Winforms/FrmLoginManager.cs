using System;
using System.Collections.Generic;
using System.Text;
using ConstructionDemo.Interfaces;
using ConstructionDemo.Datasets;
using CGS.RemoteAccess;
using ConstructionDemo.Client.WebReferences;
using CGS.Globals;
using System.IO;
using System.Data;


namespace ConstructionDemo.Client.Winforms
{
    class FrmLoginManager
    {


        private dsUser GetUser(string cUserID, string cPassword)
        {
            cgsGlobals oGlobals = new cgsGlobals();
            ClientRemoteAccess oRemoteAccess = new ClientRemoteAccess();
            oRemoteAccess.tInterface = typeof(ConstructionDemo.Interfaces.IUser<>);
            oRemoteAccess.cServiceName = "User";

            if (oRemoteAccess.UsingWebServices() == true)
                oRemoteAccess.wService = new wUserRef();

            object oReturnObject = oRemoteAccess.GetAccessObject();
            dsUser odsUser = new dsUser();

            if (oRemoteAccess.UsingWebServices() == true)
            {
                IUser<string> oUser;
                oUser = (IUser<string>)oReturnObject;
                string cXMLResults = oUser.GetUser(cUserID, cPassword, oGlobals.nDataBaseKey);
                odsUser.ReadXml(new StringReader(cXMLResults),
                                 XmlReadMode.InferSchema);
            }
            else
            {
                IUser<dsUser> oUser;
                oUser = (IUser<dsUser>)oReturnObject;
                odsUser = oUser.GetUser(cUserID, cPassword, oGlobals.nDataBaseKey);
            }

            return odsUser;

        }



        public string ValidateUserID(string cUserID, string cPassword)
        {

            string cMessage = "";
            dsUser odsUser = this.GetUser(cUserID, cPassword);

            if (odsUser.dtUser.Count == 0)
                cMessage = "User not found";
            else
            {
                cMessage = odsUser.dtUser[0].Message;
                cgsGlobals oGlobals = new cgsGlobals();
                oGlobals.cUserName = odsUser.dtUser[0].UserName;
            }

            return cMessage;
        }


    }
}
