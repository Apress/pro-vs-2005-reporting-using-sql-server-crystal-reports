using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ConstructionDemo.CrystalReports;
 

namespace ConstructionDemo.Client.Winforms
{
    public partial class FrmReportLauncher : CGS.Winforms.Forms.cgsFrmResponse
    {
        public FrmReportLauncher()
        {
            InitializeComponent();
        }

        private void FrmReportLauncher_Load(object sender, EventArgs e)
        {
            this.LoadReports();
        }


        private void LoadReports()
        {
            this.lstReports.Items.Add("TimeSheet/Labor Report");
            this.lstReports.Items.Add("Job Construction Profit Summary Report");
            this.lstReports.Items.Add("Project Timeline (Gantt) Chart");
            this.lstReports.Items.Add("Client Invoices");
            this.lstReports.Items.Add("Aging Receivables Report");
            this.lstReports.Items.Add("Report/Graph of Labor and Costs");
            this.lstReports.Items.Add("Stacked Bar Chart of Monthly Labor/Costs");
            this.lstReports.Items.Add("Construction Job Closeout Profile Report");
            this.lstReports.Items.Add("XY Scatter Graph");
            this.lstReports.Items.Add("Generate PPT slideshow");
            
        }

        private void Preview(CrystalDecisions.CrystalReports.Engine.ReportDocument oReport)
             {
            CGS.CrystalReportsTools.ccCrystalManager oCrystal = new CGS.CrystalReportsTools.ccCrystalManager();
            oCrystal.PreviewReport(oReport, "Preview");



             }


        private void btnContinue_Click(object sender, EventArgs e)
        {
            switch(this.lstReports.SelectedIndex) {
                case 0:
                    this.Preview(new RPT_TimeSheet());
                    break;
                case 2:
                    this.Preview(new RPT_JobGanttChart());
                    break;
                case 4:
                    FrmAgingReport oAgingReport = new FrmAgingReport();
                    oAgingReport.ShowDialog();
                    break;
                case 5:
                    this.Preview(new RPT_CostLaborReportGraph());
                    break;
                case 6:
                    this.Preview(new RPT_CostStackedBarGraph());
                    break;
                case 8:
                    this.Preview(new ScatterGraph());
                    break;
            //    case 9:
              //      this.GeneratePPT();
                //    break;

          


            }

    
        }

        //private void GeneratePPT()
        //{
        //    PowerPointTools.PowerPointTools oPPT = new PowerPointTools.PowerPointTools();
        //    oPPT.LaunchPPT();



        //    oPPT.SetTemplate("C:\\Program Files\\Microsoft Office\\Templates\\Presentation Designs\\pixel.pot");     //Quadrant.pot");


        //    //            oPPT.SetTemplate("c:\\ppt\\plain.pot");

        //    oPPT.BuildTitlePage("Construction Demo", "Prepared by Common Ground Solutions");
        //    //oPPT.AddPicture("C:\\chiefs.gif");
        //    oPPT.AddPicture("C:\\construction.jpg");

        //    List<PPTBulletList> oBulletList = new List<PPTBulletList>();
        //    oBulletList.Add(new PPTBulletList("Customer Satisfaction", PPTBulletList.IndentLevel.NoIndent));
        //    oBulletList.Add(new PPTBulletList("Many referrals for 2006", PPTBulletList.IndentLevel.Indent1));
        //    oBulletList.Add(new PPTBulletList("Repeat business from five customers", PPTBulletList.IndentLevel.Indent1));
        //    oBulletList.Add(new PPTBulletList("Jobs mentioned in local business journal", PPTBulletList.IndentLevel.Indent1));
        //    oBulletList.Add(new PPTBulletList("Every customer invoice paid on time", PPTBulletList.IndentLevel.Indent1));


        //    oBulletList.Add(new PPTBulletList("Company Growth", PPTBulletList.IndentLevel.NoIndent));
        //    oBulletList.Add(new PPTBulletList("5 new hires in 2005", PPTBulletList.IndentLevel.Indent1));
        //    oBulletList.Add(new PPTBulletList("3 new hires in 2004", PPTBulletList.IndentLevel.Indent1));
        //    oBulletList.Add(new PPTBulletList("No turnover in 2005", PPTBulletList.IndentLevel.Indent1));

        //    oBulletList.Add(new PPTBulletList("Safety, Safety, Safety", PPTBulletList.IndentLevel.NoIndent));
        //    oBulletList.Add(new PPTBulletList("127 days without an accident", PPTBulletList.IndentLevel.Indent1));
        //    oBulletList.Add(new PPTBulletList("Only 3 accidents in 2005", PPTBulletList.IndentLevel.Indent1));


        //    oBulletList.Add(new PPTBulletList("Company Profits, everyone Profits", PPTBulletList.IndentLevel.NoIndent));
        //    oBulletList.Add(new PPTBulletList("2.4 Million Revenue, up from 1.9 Million in 2004", PPTBulletList.IndentLevel.Indent1));
        //    oBulletList.Add(new PPTBulletList("Employee Profit Sharing instituted in 2005", PPTBulletList.IndentLevel.Indent1));



        //    // Etc, etc.

        //    oPPT.BuildBulletPage("2005 Summary", oBulletList);


        //    // Code to generate a page with a Title and a table
        //    DataTable DtTable = new DataTable();
        //    DtTable.Columns.Add("Job Number", typeof(String));
        //    DtTable.Columns.Add("Client", typeof(String));
        //    DtTable.Columns.Add("Completed", typeof(String));
        //    DtTable.Columns.Add("TotLabor", typeof(Decimal));
        //    DtTable.Columns.Add("TotMaterial", typeof(Int32));
        //    DtTable.Columns.Add("TotProfit", typeof(Int32));

        //    DtTable.Rows.Add("167 - New Visitor Center", "Smithson Masonry", "July 2005", 5010, 72116, 19120);
        //    DtTable.Rows.Add("212 - Summit Center", "Dave Hamilton", "Sep 2005", 10111, 32118, 11120);
        //    DtTable.Rows.Add("321 - Manxler Homes", "Smithson Masonry", "Nov 2005", 9227, 29012, 10020);
        //    DtTable.Rows.Add("177 - Summit Center", "Dave Hamilton", "Sep 2005", 10111, 32118, 11120);
        //    DtTable.Rows.Add("109 - K.T. Repairs", "Lexington Construction", "Apr 2005", 4119, 15023, 7020);



        //    DataTable DtHeading = new DataTable();
        //    DtHeading.Columns.Add("ColumnName", typeof(String));
        //    DtHeading.Columns.Add("Alignment", typeof(Int32));
        //    DtHeading.Rows.Add("Job #/Description", 2);
        //    DtHeading.Rows.Add("Client", 2);
        //    DtHeading.Rows.Add("Completed", 2);
        //    DtHeading.Rows.Add("Labor $", 4);
        //    DtHeading.Rows.Add("Material $", 4);
        //    DtHeading.Rows.Add("Profit $", 4);



        //    oPPT.BuildTablePage("Top Five Construction Jobs for 2005", DtTable, DtHeading);




        //    DataTable DtPieChart = new DataTable();
        //    DtPieChart.Columns.Add("Category", typeof(System.String));
        //    DtPieChart.Columns.Add("Amount", typeof(System.Int32));

        //    DtPieChart.Rows.Add("Labor", 167734);
        //    DtPieChart.Rows.Add("Material", 26148);
        //    DtPieChart.Rows.Add("Other", 13805 + 11920);




        //    //            DtPieChart.Rows.Add("Holmes", 74); 
        //    //          DtPieChart.Rows.Add("Gonzales", 71);
        //    //        DtPieChart.Rows.Add("Kennison", 56);
        //    //      DtPieChart.Rows.Add("Morton", 50);
        //    //    DtPieChart.Rows.Add("Hall", 40);
        //    //  DtPieChart.Rows.Add("Others", 48);

        //    DataTable DtReceiverData = new DataTable();
        //    DtReceiverData.Columns.Add("Quarter", typeof(System.String));
        //    DtReceiverData.Columns.Add("Labor", typeof(System.Int32));
        //    DtReceiverData.Columns.Add("Materials", typeof(System.Int32));
        //    DtReceiverData.Columns.Add("Other", typeof(System.Int32));

        //    DtReceiverData.Rows.Add("'Q1", 42300, 9640, 3400 + 2420);
        //    DtReceiverData.Rows.Add("'Q2", 40700, 5330, 2860 + 3560);
        //    DtReceiverData.Rows.Add("'Q3", 42260, 5100, 3666 + 3540);
        //    DtReceiverData.Rows.Add("'Q4", 42474, 6078, 3879 + 2400);



        //    DataTable DtHeading2 = new DataTable();
        //    DtHeading2.Columns.Add("ColumnName", typeof(System.String));
        //    DtHeading2.Columns.Add("Alignment", typeof(System.Int32));
        //    DtHeading2.Rows.Add("Quarter", 2);
        //    DtHeading2.Rows.Add("Labor", 4);
        //    DtHeading2.Rows.Add("Materials", 4);
        //    DtHeading2.Rows.Add("Other", 4);

        //    oPPT.BuildTablePieChartPage("2005 Labor/Costs by Quarter", DtReceiverData, DtHeading2, "Labor/Costs Breakdown", DtPieChart);





        //    DataTable DtLineChart = new DataTable();
        //    // Column names are not important 
        //    // Just need to define the first column as the X-Axis,
        //    // and columns 2-N as the groups for the Y-Axis

        //    DtLineChart.Columns.Add("WeekNumber", typeof(String));
        //    DtLineChart.Columns.Add("Labor", typeof(String));
        //    DtLineChart.Columns.Add("Materials", typeof(String));
        //    DtLineChart.Columns.Add("PettyCash", typeof(String));
        //    DtLineChart.Columns.Add("Other", typeof(String));
        //    DtLineChart.Columns.Add("Total LY", typeof(String));

        //    //DtLineChart.Rows.Add(System.DBNull.Value,2003,2004,2005,2006);

        //    DtLineChart.Rows.Add(System.DBNull.Value, "Labor", "Material", "Fuel", "Petty Cash", "Total LY");

        //    DtLineChart.Rows.Add("'Jan 05", "14000", "1780", "1100", "140", "13500");
        //    DtLineChart.Rows.Add("'Feb 05", "14100", "4780", "1200", "1140", "13600");
        //    DtLineChart.Rows.Add("'Mar 05", "14200", "3080", "1100", "1140", "13900");
        //    DtLineChart.Rows.Add("'Apr 05", "13000", "1980", "1300", "1180", "14200");
        //    DtLineChart.Rows.Add("'May 05", "13800", "1580", "1450", "1240", "11800");
        //    DtLineChart.Rows.Add("'Jun 05", "13900", "1770", "110", "1140", "16788");
        //    DtLineChart.Rows.Add("'Jul 05", "13960", "1710", "1111", "1240", "14591");
        //    DtLineChart.Rows.Add("'Aug 05", "14200", "1720", "1222", "1140", "14204");
        //    DtLineChart.Rows.Add("'Sep 05", "14100", "1670", "1333", "1160", "15021");
        //    DtLineChart.Rows.Add("'Oct 05", "14075", "1120", "1555", "1170", "16015");
        //    DtLineChart.Rows.Add("'Nov 05", "14133", "1667", "1111", "1120", "15943");
        //    DtLineChart.Rows.Add("'Dec 05", "14266", "3291", "1213", "110", "14201");

        //    // Parameters are Slide title, Data, X-Axis Title, Y-Axis Title

        //    //            oPPT.BuildLineChartPage("Trent Green QB Rating: 2003 vs 2004", DtLineChart, "Week #", "QB Rating");





        //    oPPT.BuildBarChartPage("", DtLineChart, "", "");





        //    DataTable DtLineChart2 = new DataTable();
        //    // Column names are not important
        //    // Just need to define the first column as the X-Axis,
        //    // and columns 2-N as the groups for the Y-Axis

        //    DtLineChart2.Columns.Add("Month", typeof(String));
        //    DtLineChart2.Columns.Add("Costs2005", typeof(Decimal));
        //    DtLineChart2.Columns.Add("Costs2004", typeof(Decimal));

        //    DtLineChart2.Rows.Add(System.DBNull.Value, 2005, 2004);

        //    DtLineChart2.Rows.Add("'Jan 05", 14000 + 1780 + 1100 + 140, 13500);
        //    DtLineChart2.Rows.Add("'Feb 05", 14100 + 4780 + 1200 + 1140, 13600);
        //    DtLineChart2.Rows.Add("'Mar 05", 14200 + 3080 + 1100 + 1140, 13900);
        //    DtLineChart2.Rows.Add("'Apr 05", 13000 + 1980 + 1300 + 1180, 14200);
        //    DtLineChart2.Rows.Add("'May 05", 13800 + 1580 + 1450 + 1240, 11800);
        //    DtLineChart2.Rows.Add("'Jun 05", 13900 + 1770 + 110 + 1140, 16788);
        //    DtLineChart2.Rows.Add("'Jul 05", 13960 + 1710 + 1111 + 1240, 14591);
        //    DtLineChart2.Rows.Add("'Aug 05", 14200 + 1720 + 1222 + 1140, 14204);
        //    DtLineChart2.Rows.Add("'Sep 05", 14100 + 1670 + 1333 + 1160, 15021);
        //    DtLineChart2.Rows.Add("'Oct 05", 14075 + 1120 + 1555 + 1170, 16015);
        //    DtLineChart2.Rows.Add("'Nov 05", 14133 + 1667 + 1111 + 1120, 15943);
        //    DtLineChart2.Rows.Add("'Dec 05", 14266 + 3291 + 1213 + 110, 14201);




        //    oPPT.BuildLineChartPage("", DtLineChart2, "", "Total Costs");





        //    //            oPPT.BuildLineChartPage("Trent Green QB Rating: 2003 vs 2004", DtLineChart, "Week #", "QB Rating");






        //    oPPT.BuildFooter("K. Goff Construction - 2005 Summary");
        //    oPPT.SetSlideTransitions();

        //    oPPT.SavePresentation("c:\\KCCHIEFS.PPT");


        //}



        private void lstReports_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


    }
}

