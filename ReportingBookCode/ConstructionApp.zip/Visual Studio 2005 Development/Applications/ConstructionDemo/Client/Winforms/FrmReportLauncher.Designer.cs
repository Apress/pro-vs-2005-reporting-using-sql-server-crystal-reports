namespace ConstructionDemo.Client.Winforms
{
    partial class FrmReportLauncher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstReports = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnContinue
            // 
            this.btnContinue.Location = new System.Drawing.Point(73, 259);
            this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(202, 259);
            // 
            // lstReports
            // 
            this.lstReports.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstReports.FormattingEnabled = true;
            this.lstReports.ItemHeight = 16;
            this.lstReports.Location = new System.Drawing.Point(12, 12);
            this.lstReports.Name = "lstReports";
            this.lstReports.Size = new System.Drawing.Size(352, 212);
            this.lstReports.TabIndex = 3;
            this.lstReports.SelectedIndexChanged += new System.EventHandler(this.lstReports_SelectedIndexChanged);
            // 
            // FrmReportLauncher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(377, 316);
            this.Controls.Add(this.lstReports);
            this.Name = "FrmReportLauncher";
            this.Text = "Select Report to Run";
            this.Load += new System.EventHandler(this.FrmReportLauncher_Load);
            this.Controls.SetChildIndex(this.lstReports, 0);
            this.Controls.SetChildIndex(this.btnContinue, 0);
            this.Controls.SetChildIndex(this.btnCancel, 0);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstReports;
    }
}
