using System;
using System.Collections.Generic;
using System.Text;
using ConstructionDemo.Interfaces;
using ConstructionDemo.Datasets;
using CGS.RemoteAccess;
using ConstructionDemo.Client.WebReferences;
using CGS.Globals;
using System.IO;
using System.Data;
using ConstructionDemo.CrystalReports;
using CGS.CrystalReportsTools;
using CrystalDecisions.CrystalReports.Engine;
 

namespace ConstructionDemo.Client.Winforms
{
    class FrmAgingReportManager
    {

        private string _cClientList ;
        public string cClientList
        {

            get { return _cClientList; }
            set { _cClientList = value; }
        }


        private DateTime _dAgingDate ;
        public DateTime dAgingDate
        {

            get { return _dAgingDate; }
            set { _dAgingDate = value; }
        }

        private bool _lDetails ;
        public bool lDetails
        {

            get { return _lDetails; }
            set { _lDetails = value; }
        }


        private string _cFootNote ;
        public string cFootNote
        {

            get { return _cFootNote; }
            set { _cFootNote = value; }
        }








        public void RunAgingReport()
        {

            dsAgingReport odsAgingReport = this.GetAgingReportResultSet();
            this.PreviewReport(odsAgingReport);
        }


        private void PreviewReport(dsAgingReport odsAgingReport)
        {
            cgsGlobals oGlobals = new cgsGlobals();
            RPT_AgingReport oRPTAgingReport = new RPT_AgingReport();
            

            // Create an instance of the Crystal Manager
            ccCrystalManager oCrystal = new ccCrystalManager();

            // Create an instance of the header/footer object
            ccReportInfo oReportInfo = new ccReportInfo();
            oReportInfo.FtrDataSource = "From Invoice Data";
            oReportInfo.FtrFootNotes = this.cFootNote;
            oReportInfo.FtrRunBy = "Run by " + oGlobals.cUserName;
            oReportInfo.FtrVersion = "Version 1.00";
            oReportInfo.HdrCompany = oGlobals.cCurrentConnection;
            oReportInfo.HdrReportTitle = "Aging Receivables Report";
            oReportInfo.HdrSubTitle1 = "Based on Invoices Aged from " +
                        dAgingDate.ToShortDateString();
            oReportInfo.HdrSubTitle2 = "Sorted by Total Aging Amount";
            oReportInfo.UserID = oGlobals.cUserID;

            oCrystal.SetReportInfo(oRPTAgingReport, oReportInfo);

            oCrystal.PushReportData(odsAgingReport, oRPTAgingReport);

            // Set the report ShowDetails Parameter
            oRPTAgingReport.SetParameterValue("ShowDetails", lDetails);


            // Show the different capabilities for output...First, do a preview
            oCrystal.PreviewReport(oRPTAgingReport, "Aging Report Preview");







      
 

// Set the run-time authentication info
// (I designed the report to directly work with a stored 
// procedure, which meant
// I authenticated with the database stored proc at design time
//
// The report will access a different server at run time, 
// so it must re-authenticate
 



        }



        private dsAgingReport GetAgingReportResultSet()
        {
            cgsGlobals oGlobals = new cgsGlobals();
            ClientRemoteAccess oRemoteAccess = new ClientRemoteAccess();
            oRemoteAccess.tInterface = 
                          typeof(ConstructionDemo.Interfaces.IAgingReport<>);
            oRemoteAccess.cServiceName = "AgingReport";

            if (oRemoteAccess.UsingWebServices() == true)
                oRemoteAccess.wService = new wAgingReportRef();

            object oReturnObject = oRemoteAccess.GetAccessObject();
            dsAgingReport odsAgingReport = new dsAgingReport();

            if (oRemoteAccess.UsingWebServices() == true)
            {
                IAgingReport<string> oAgingReport;
                oAgingReport = (IAgingReport<string>)oReturnObject;
                string cXMLResults = oAgingReport.GetAgingReport
                         (this.dAgingDate, this.lDetails, this.cClientList, oGlobals.nDataBaseKey);
                odsAgingReport.ReadXml(new StringReader(cXMLResults),
                                 XmlReadMode.InferSchema);
            }
            else
            {
                IAgingReport<dsAgingReport> oAgingReport;
                oAgingReport = (IAgingReport<dsAgingReport>)oReturnObject;
                odsAgingReport = oAgingReport.GetAgingReport
                         (this.dAgingDate, this.lDetails, this.cClientList, oGlobals.nDataBaseKey);
            }

           // odsAgingReport.WriteXml("c:\\myxmlfiles\\dsagingreport.xml");`Q
            return odsAgingReport;

        }
    }
}