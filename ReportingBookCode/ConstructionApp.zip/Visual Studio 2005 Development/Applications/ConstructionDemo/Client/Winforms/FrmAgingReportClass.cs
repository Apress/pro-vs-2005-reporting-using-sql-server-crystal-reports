using System;
using System.Collections.Generic;
using System.Text;
using ConstructionDemo.Interfaces;
using ConstructionDemo.Datasets;
using CGS.RemoteAccess;
using ConstructionDemo.Client.WebReferences;
using CGS.Globals;
using System.IO;
using System.Data;
using ConstructionDemo.CrystalReports;
using CGS.CrystalReportsTools;

namespace ConstructionDemo.Client.Winforms
{
    class FrmAgingReportClass
    {


        public void RunAgingReport(string cClientList, DateTime dAgingDate, bool lDetails, string cFootNote)
        {

            dsAgingReport odsAgingReport = this.GetAgingReportResultSet(cClientList, dAgingDate, lDetails, cFootNote);
            this.PreviewReport(odsAgingReport, cClientList,dAgingDate, lDetails,cFootNote);
        }


        private void PreviewReport(dsAgingReport odsAgingReport, string cClientList, DateTime dAgingDate, bool lDetails, string cFootNote)
        {
            cgsGlobals oGlobals = new cgsGlobals();
            RPT_AgingReport oRPTAgingReport = new RPT_AgingReport();
            

            // Create an instance of the Crystal Manager
            ccCrystalManager oCrystal = new ccCrystalManager();

            // Create an instance of the header/footer object
            ccReportInfo oReportInfo = new ccReportInfo();
            oReportInfo.FtrDataSource = "From Invoice Data";
            oReportInfo.FtrFootNotes = cFootNote;
            oReportInfo.FtrRunBy = "Run by " + oGlobals.cUserName;
            oReportInfo.FtrVersion = "Version 1.00";
            oReportInfo.HdrCompany = oGlobals.cCurrentConnection;
            oReportInfo.HdrReportTitle = "Aging Receivables Report";
            oReportInfo.HdrSubTitle1 = "Based on Invoices Aged from " + dAgingDate.ToShortDateString();
            oReportInfo.HdrSubTitle2 = "Sorted by Total Aging Amount";
            oReportInfo.UserID = oGlobals.cUserID;

            oCrystal.SetReportInfo(oRPTAgingReport, oReportInfo);

            oCrystal.PushReportData(odsAgingReport, oRPTAgingReport);

            // Set the report ShowDetails Parameter
            oRPTAgingReport.SetParameterValue("ShowDetails", lDetails);


            // Show the different capabilities for output...First, do a preview
            oCrystal.PreviewReport(oRPTAgingReport, "Preview");



        }



        private dsAgingReport GetAgingReportResultSet(string cClientList, DateTime dAgingDate, bool lDetails, string cFootNote)
        {
            cgsGlobals oGlobals = new cgsGlobals();
            ClientRemoteAccess oRemoteAccess = new ClientRemoteAccess();
            oRemoteAccess.tInterface = typeof(ConstructionDemo.Interfaces.IAgingReport<>);
            oRemoteAccess.cServiceName = "AgingReport";

            if (oRemoteAccess.UsingWebServices() == true)
                oRemoteAccess.wService = new wAgingReportRef();

            object oReturnObject = oRemoteAccess.GetAccessObject();
            dsAgingReport odsAgingReport = new dsAgingReport();

            if (oRemoteAccess.UsingWebServices() == true)
            {
                IAgingReport<string> oAgingReport;
                oAgingReport = (IAgingReport<string>)oReturnObject;
                string cXMLResults = oAgingReport.GetAgingReport(dAgingDate, lDetails, cClientList, oGlobals.nDataBaseKey);
                odsAgingReport.ReadXml(new StringReader(cXMLResults),
                                 XmlReadMode.InferSchema);
            }
            else
            {
                IAgingReport<dsAgingReport> oAgingReport;
                oAgingReport = (IAgingReport<dsAgingReport>)oReturnObject;
                odsAgingReport = oAgingReport.GetAgingReport(dAgingDate, lDetails, cClientList, oGlobals.nDataBaseKey);
            }

            return odsAgingReport;

        }
    }
}