using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CGS.Globals;


namespace ConstructionDemo.Client.Winforms
{
    public partial class FrmLogin : CGS.Winforms.AppForms.cgsFrmLogin
    {
        FrmLoginManager oLoginManager;
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {
        }

        protected override void SetConnectionInfo()
        {
            base.SetConnectionInfo();
        }

        protected override bool ValidateUserID()
        {
            cgsGlobals oGlobals = new cgsGlobals();
            bool lRetVal = true;
            string cUserID = this.txtUserID.Text.Trim();
            string cPassword = this.txtPassword.Text.Trim();
            oGlobals.cCurrentConnection = this.cboConnections.Text;

            oLoginManager = new  FrmLoginManager();

            string cMessage = oLoginManager.ValidateUserID(cUserID, cPassword);
            if(cMessage.Length > 0) {
                MessageBox.Show(cMessage,oGlobals.cCurrentConnection);
                lRetVal = false;
            }


             return lRetVal;


        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {

        }




    }
}

