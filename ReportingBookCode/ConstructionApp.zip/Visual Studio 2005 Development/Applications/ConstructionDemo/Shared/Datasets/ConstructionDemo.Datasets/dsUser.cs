﻿namespace ConstructionDemo.Datasets {


    partial class dsUser
    {
        partial class dtUserDataTable
        {
        }
    }
}
