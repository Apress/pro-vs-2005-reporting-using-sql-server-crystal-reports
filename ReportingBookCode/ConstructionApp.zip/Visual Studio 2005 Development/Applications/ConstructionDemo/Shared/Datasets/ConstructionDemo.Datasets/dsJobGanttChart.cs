﻿namespace ConstructionDemo.Datasets {


    partial class dsJobGanttChart
    {
        partial class dtClientsDataTable
        {
        }
    
        partial class dtPageControlDataTable
        {
        }
    }
}
