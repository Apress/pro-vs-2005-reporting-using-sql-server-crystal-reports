//using System;
//using System.Collections.Generic;
//using System.Text;

//namespace ConstructionDemo.Interfaces
//{
//    public interface IAgingReport<T>
//    {
//        T GetAgingReport(DateTime dAsOfDate, bool lDetails, string cClientList, int nDBKey);
//    }

//    public interface IJobSummary<T>  
//    {
//        T GetJobSummary(string cJobList, int nDBKey);
//    }

//}



using System;
using System.Collections.Generic;
using System.Text;

namespace ConstructionDemo.Interfaces
{
    // Utilizes .NET Generics � parameter declaration for a DataSet, or custom list, 
    // or even an XML string
    public interface IAgingReport<T>
    {
        T GetAgingReport(DateTime dAsOfDate, bool lDetails, string cClientList,
                                    int nDBKey);
    }

    public interface ITimeSheetReport<T>
    {
        T GetTimeSheetReport(DateTime dStartDate, DateTime dEndDate,
                  bool lShowDetails, string cJobList, string cEmployeeList,
                  int nDBKey);
    }

    public interface IUser<T>
    {
        T GetUser(string cUserID, string cPassword, int nDBKey);
    }
    // etc, etc.

}
