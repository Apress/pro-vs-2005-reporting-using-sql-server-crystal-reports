using System;
using System.Collections.Generic;
using System.Text;

namespace ConstructionDemo.Interfaces
{
    public class Class1
    {
    }
}
