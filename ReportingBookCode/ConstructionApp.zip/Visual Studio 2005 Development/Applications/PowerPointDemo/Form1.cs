using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CGS.PowerPointTools;
 

namespace PowerPointDemo
{
    public partial class Form1 : Form
    {

        PowerPointTools oPPT;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            oPPT = new CGS.PowerPointTools.PowerPointTools();
            oPPT.LaunchPPT();

            this.SetMainPage();
            this.WriteSummaryBulletPage();
            this.WriteTablePage();
            this.WritePieChartPage();
            this.WriteBarChartPage();
            this.WriteLineChartPage();
            this.FinishPPT();
        }


        private void SetMainPage()
        {

            string cFile = System.IO.Directory.GetCurrentDirectory() + "\\pixel.pot ";
            string cLogo = System.IO.Directory.GetCurrentDirectory() + "\\construction.jpg";

            //oPPT.SetTemplate("C:\\Program Files\\Microsoft Office\\Templates\\Presentation Designs\\pixel.pot");     //Quadrant.pot");
            oPPT.SetTemplate(cFile);
            oPPT.BuildTitlePage("Construction Demo", "Prepared by Common Ground Solutions");
            oPPT.AddPicture(cLogo);


        }


        private void WriteSummaryBulletPage()
        {
            List<PPTBulletList> oBulletList = new List<PPTBulletList>();
            oBulletList.Add(new PPTBulletList("Customer Satisfaction", PPTBulletList.IndentLevel.NoIndent));
            oBulletList.Add(new PPTBulletList("Many referrals for 2006", PPTBulletList.IndentLevel.Indent1));
            oBulletList.Add(new PPTBulletList("Repeat business from five customers", PPTBulletList.IndentLevel.Indent1));
            oBulletList.Add(new PPTBulletList("Jobs mentioned in local business journal", PPTBulletList.IndentLevel.Indent1));
            oBulletList.Add(new PPTBulletList("Every customer invoice paid on time", PPTBulletList.IndentLevel.Indent1));

            oBulletList.Add(new PPTBulletList("Company Growth", PPTBulletList.IndentLevel.NoIndent));
            oBulletList.Add(new PPTBulletList("5 new hires in 2005", PPTBulletList.IndentLevel.Indent1));
            oBulletList.Add(new PPTBulletList("3 new hires in 2004", PPTBulletList.IndentLevel.Indent1));
            oBulletList.Add(new PPTBulletList("No turnover in 2005", PPTBulletList.IndentLevel.Indent1));

            oBulletList.Add(new PPTBulletList("Safety, Safety, Safety", PPTBulletList.IndentLevel.NoIndent));
            oBulletList.Add(new PPTBulletList("127 days without an accident", PPTBulletList.IndentLevel.Indent1));
            oBulletList.Add(new PPTBulletList("Only 3 accidents in 2005", PPTBulletList.IndentLevel.Indent1));


            oBulletList.Add(new PPTBulletList("Company Profits, everyone Profits", PPTBulletList.IndentLevel.NoIndent));
            oBulletList.Add(new PPTBulletList("2.4 Million Revenue, up from 1.9 Million in 2004", PPTBulletList.IndentLevel.Indent1));
            oBulletList.Add(new PPTBulletList("Employee Profit Sharing instituted in 2005", PPTBulletList.IndentLevel.Indent1));


            oPPT.BuildBulletPage("2005 Summary", oBulletList);

        }

        private void WriteTablePage()
        {


            // Code to generate a page with a Title and a table
            DataTable dtJobTable = new DataTable();
            dtJobTable.Columns.Add("Job Number", typeof(String));
            dtJobTable.Columns.Add("Client", typeof(String));
            dtJobTable.Columns.Add("Completed", typeof(String));
            dtJobTable.Columns.Add("TotLabor", typeof(Decimal));
            dtJobTable.Columns.Add("TotMaterial", typeof(Int32));
            dtJobTable.Columns.Add("TotProfit", typeof(Int32));

            dtJobTable.Rows.Add("167 - New Visitor Center", "Smithson Masonry", "July 2005", 5010, 72116, 19120);
            dtJobTable.Rows.Add("212 - Summit Center", "Dave Hamilton", "Sep 2005", 10111, 32118, 11120);
            dtJobTable.Rows.Add("321 - Manxler Homes", "Smithson Masonry", "Nov 2005", 9227, 29012, 10020);
            dtJobTable.Rows.Add("177 - Summit Center", "Dave Hamilton", "Sep 2005", 10111, 32118, 11120);
            dtJobTable.Rows.Add("109 - K.T. Repairs", "Lexington Construction", "Apr 2005", 4119, 15023, 7020);



            DataTable dtJobHeading = new DataTable();
            dtJobHeading.Columns.Add("ColumnName", typeof(String));
            dtJobHeading.Columns.Add("RightAlign", typeof(Boolean));
            dtJobHeading.Rows.Add("Job #/Description", false);
            dtJobHeading.Rows.Add("Client", false);
            dtJobHeading.Rows.Add("Completed", false);
            dtJobHeading.Rows.Add("Labor $", true);
            dtJobHeading.Rows.Add("Material $", true);
            dtJobHeading.Rows.Add("Profit $", true);
            oPPT.BuildTablePage("Top Five Construction Jobs for 2005", dtJobTable, dtJobHeading);

        }

        private void WritePieChartPage()
        {


            DataTable DtPieChart = new DataTable();
            DtPieChart.Columns.Add("Category", typeof(System.String));
            DtPieChart.Columns.Add("Amount", typeof(System.Int32));

            DtPieChart.Rows.Add("Labor", 167734);
            DtPieChart.Rows.Add("Material", 26148);
            DtPieChart.Rows.Add("Other", 13805 + 11920);


            DataTable dtLaborCostData = new DataTable();
            dtLaborCostData.Columns.Add("Quarter", typeof(System.String));
            dtLaborCostData.Columns.Add("Labor", typeof(System.Int32));
            dtLaborCostData.Columns.Add("Materials", typeof(System.Int32));
            dtLaborCostData.Columns.Add("Other", typeof(System.Int32));

            dtLaborCostData.Rows.Add("'Q1", 42300, 9640, 3400 + 2420);
            dtLaborCostData.Rows.Add("'Q2", 40700, 5330, 2860 + 3560);
            dtLaborCostData.Rows.Add("'Q3", 42260, 5100, 3666 + 3540);
            dtLaborCostData.Rows.Add("'Q4", 42474, 6078, 3879 + 2400);



            DataTable DtLaborCostHeading = new DataTable();
            DtLaborCostHeading.Columns.Add("ColumnName", typeof(System.String));
            DtLaborCostHeading.Columns.Add("RightAlign", typeof(System.Boolean));
            DtLaborCostHeading.Rows.Add("Quarter", false);
            DtLaborCostHeading.Rows.Add("Labor", true);
            DtLaborCostHeading.Rows.Add("Materials", true);
            DtLaborCostHeading.Rows.Add("Other", true);

            oPPT.BuildTablePieChartPage("2005 Labor/Costs by Quarter", dtLaborCostData, DtLaborCostHeading, "Labor/Costs Breakdown", DtPieChart);

        }


        private void WriteBarChartPage()
        {


            DataTable DtBarChartHeading = new DataTable();
            DtBarChartHeading.Columns.Add("ColumnName", typeof(System.String));
            DtBarChartHeading.Columns.Add("RightAlign", typeof(System.Int32));
            DtBarChartHeading.Rows.Add("Week Number", false);
            DtBarChartHeading.Rows.Add("Labor", true);
            DtBarChartHeading.Rows.Add("Materials", true);
            DtBarChartHeading.Rows.Add("Fuel", true);
            DtBarChartHeading.Rows.Add("Petty Cash", true);
            DtBarChartHeading.Rows.Add("Total LY", true);


            DataTable dtBarChart = new DataTable();
            // Column names are not important 
            // Just need to define the first column as the X-Axis,
            // and columns 2-N as the groups for the Y-Axis

            dtBarChart.Columns.Add("WeekNumber", typeof(String));
            dtBarChart.Columns.Add("Labor", typeof(Decimal));
            dtBarChart.Columns.Add("Materials", typeof(Decimal));
            dtBarChart.Columns.Add("PettyCash", typeof(Decimal));
            dtBarChart.Columns.Add("Other", typeof(Decimal));
            dtBarChart.Columns.Add("Total LY", typeof(Decimal));


            dtBarChart.Rows.Add("'Jan 05", 14000, 1780, 1100, 140, 13500);
            dtBarChart.Rows.Add("'Feb 05", 14100, 4780, 1200, 1140, 13600);
            dtBarChart.Rows.Add("'Mar 05", 14200, 3080, 1100, 1140, 13900);
            dtBarChart.Rows.Add("'Apr 05", 13000, 1980, 1300, 1180, 14200);
            dtBarChart.Rows.Add("'May 05", 13800, 1580, 1450, 1240, 11800);
            dtBarChart.Rows.Add("'Jun 05", 13900, 1770, 110, 1140, 16788);
            dtBarChart.Rows.Add("'Jul 05", 13960, 1710, 1111, 1240, 14591);
            dtBarChart.Rows.Add("'Aug 05", 14200, 1720, 1222, 1140, 14204);
            dtBarChart.Rows.Add("'Sep 05", 14100, 1670, 1333, 1160, 15021);
            dtBarChart.Rows.Add("'Oct 05", 14075, 1120, 1555, 1170, 16015);
            dtBarChart.Rows.Add("'Nov 05", 14133, 1667, 1111, 1120, 15943);
            dtBarChart.Rows.Add("'Dec 05", 14266, 3291, 1213, 110, 14201);

            oPPT.BuildBarChartPage("", dtBarChart, "", "", DtBarChartHeading);

        }


        private void WriteLineChartPage()
        {

            DataTable dtLineChart = new DataTable();
            // Column names are not important
            // Just need to define the first column as the X-Axis,
            // and columns 2-N as the groups for the Y-Axis

            dtLineChart.Columns.Add("Month", typeof(String));
            dtLineChart.Columns.Add("Costs2005", typeof(Decimal));
            dtLineChart.Columns.Add("Costs2004", typeof(Decimal));

            dtLineChart.Rows.Add(System.DBNull.Value, 2005, 2004);

            dtLineChart.Rows.Add("'Jan 05", 14000 + 1780 + 1100 + 140, 13500);
            dtLineChart.Rows.Add("'Feb 05", 14100 + 4780 + 1200 + 1140, 13600);
            dtLineChart.Rows.Add("'Mar 05", 14200 + 3080 + 1100 + 1140, 13900);
            dtLineChart.Rows.Add("'Apr 05", 13000 + 1980 + 1300 + 1180, 14200);
            dtLineChart.Rows.Add("'May 05", 13800 + 1580 + 1450 + 1240, 11800);
            dtLineChart.Rows.Add("'Jun 05", 13900 + 1770 + 110 + 1140, 16788);
            dtLineChart.Rows.Add("'Jul 05", 13960 + 1710 + 1111 + 1240, 14591);
            dtLineChart.Rows.Add("'Aug 05", 14200 + 1720 + 1222 + 1140, 14204);
            dtLineChart.Rows.Add("'Sep 05", 14100 + 1670 + 1333 + 1160, 15021);
            dtLineChart.Rows.Add("'Oct 05", 14075 + 1120 + 1555 + 1170, 16015);
            dtLineChart.Rows.Add("'Nov 05", 14133 + 1667 + 1111 + 1120, 15943);
            dtLineChart.Rows.Add("'Dec 05", 14266 + 3291 + 1213 + 110, 14201);

            oPPT.BuildLineChartPage("", dtLineChart, "", "Total Costs");
        }


        private void FinishPPT()
        {



            oPPT.BuildFooter("K. Goff Construction - 2005 Summary");
            oPPT.SetSlideTransitions();

            oPPT.SavePresentation("c:\\construction.PPT");

        }

    



    }
}
