using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CGS.Globals;
using CGS.RemoteAccess;

namespace CGS.Winforms.AppForms
{
    public partial class cgsFrmLogin : CGS.Winforms.Forms.cgsFrmResponse
    {
        DataSet DsAvailableConnections;

        private DataRow _Dr;	// Set at startup when user logs in and selects the connection profile
        public DataRow Dr
        {
            get { return _Dr; }
            set { _Dr = value; }
        }

        cgsGlobals oGlobals;
        private bool lLoaded = false;


        public cgsFrmLogin()
        {
            InitializeComponent();
        }


        private void cgsFrmLogin_Load(object sender, EventArgs e)
        {
            oGlobals = new cgsGlobals();
            if (oGlobals.lAppRunning == true)
                if (this.lLoaded == false)
                {
                    this.PopulateConnections();
                    this.SetBindings();
                    this.lLoaded = true;
                }
        }


        private void SetBindings()
        {
            this.txtUserID.DataBindings.Add("Text", oGlobals, "cUserID");
            this.txtPassword.DataBindings.Add("Text", oGlobals, "cUserPassword");
        }




        protected virtual void PopulateConnections()
        {
            this.DsAvailableConnections = new DataSet();
            if (System.IO.File.Exists(System.IO.Directory.GetCurrentDirectory() + "\\connect.xml"))
            {
                this.DsAvailableConnections.ReadXml(System.IO.Directory.GetCurrentDirectory() + "\\connect.xml");
                foreach (DataRow Dr in this.DsAvailableConnections.Tables[0].Rows)
                    this.cboConnections.Items.Add(Dr["Description"]);
                if (this.cboConnections.Items.Count > 0)
                    this.cboConnections.SelectedIndex = 0;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            this.UserLogin();
        }


        protected virtual bool ValidateUserID()
        {
            return false;
        }



        protected virtual void UserLogin()
        {
            this.SetMessageOn("Connecting for user " + oGlobals.cUserID.ToString().Trim() + "...please wait");
            this.SetConnectionInfo();
            if (this.ValidateUserID() == true)
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            this.SetMessageOff();
        }


        protected virtual void SetConnectionInfo()
        {
            // Set the communcation properties

            ClientRemoteAccess oRemoteAccess = new ClientRemoteAccess();
            this.Dr = this.DsAvailableConnections.Tables[0].Rows[this.cboConnections.SelectedIndex];

            oRemoteAccess.nConnectionType = (ClientRemoteAccess.ConnectionTypeOptions)Convert.ToInt32(Dr["ConnectionType"]);
            oRemoteAccess.cWebServiceURL = (string)Dr["ServerAddress"];
            oRemoteAccess.cTcpServer = (string)Dr["ServerAddress"];
            oRemoteAccess.nTCPPort = Convert.ToInt32(Dr["PortNumber"]);
            oRemoteAccess.cDescription = (string)Dr["Description"];
            oGlobals.nDataBaseKey = Convert.ToInt32(this.Dr["DbKey"]);

        }



    }
}

