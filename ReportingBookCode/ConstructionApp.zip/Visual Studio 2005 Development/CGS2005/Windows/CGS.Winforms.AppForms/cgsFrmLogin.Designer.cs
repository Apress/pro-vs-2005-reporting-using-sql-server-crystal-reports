namespace CGS.Winforms.AppForms
{
    partial class cgsFrmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(cgsFrmLogin));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cgsLabel1 = new CGS.Winforms.Controls.cgsLabel();
            this.cgsLabel2 = new CGS.Winforms.Controls.cgsLabel();
            this.txtUserID = new CGS.Winforms.Controls.cgsMaskedTextBox();
            this.txtPassword = new CGS.Winforms.Controls.cgsMaskedTextBox();
            this.cgsLabel3 = new CGS.Winforms.Controls.cgsLabel();
            this.cboConnections = new CGS.Winforms.Controls.cgsComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnContinue
            // 
            this.btnContinue.Location = new System.Drawing.Point(52, 303);
            this.btnContinue.TabIndex = 3;
            this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(182, 303);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(336, 58);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // cgsLabel1
            // 
            this.cgsLabel1.AutoSize = true;
            this.cgsLabel1.Font = new System.Drawing.Font("Verdana", 8F);
            this.cgsLabel1.Location = new System.Drawing.Point(35, 77);
            this.cgsLabel1.Name = "cgsLabel1";
            this.cgsLabel1.Size = new System.Drawing.Size(51, 13);
            this.cgsLabel1.TabIndex = 7;
            this.cgsLabel1.Text = "User ID";
            // 
            // cgsLabel2
            // 
            this.cgsLabel2.AutoSize = true;
            this.cgsLabel2.Font = new System.Drawing.Font("Verdana", 8F);
            this.cgsLabel2.Location = new System.Drawing.Point(35, 140);
            this.cgsLabel2.Name = "cgsLabel2";
            this.cgsLabel2.Size = new System.Drawing.Size(61, 13);
            this.cgsLabel2.TabIndex = 8;
            this.cgsLabel2.Text = "Password";
            // 
            // txtUserID
            // 
            this.txtUserID.Font = new System.Drawing.Font("Verdana", 8F);
            this.txtUserID.Location = new System.Drawing.Point(35, 93);
            this.txtUserID.Name = "txtUserID";
            this.txtUserID.Size = new System.Drawing.Size(270, 20);
            this.txtUserID.TabIndex = 0;
            // 
            // txtPassword
            // 
            this.txtPassword.Font = new System.Drawing.Font("Verdana", 8F);
            this.txtPassword.Location = new System.Drawing.Point(35, 156);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(267, 20);
            this.txtPassword.TabIndex = 1;
            this.txtPassword.UseSystemPasswordChar = true;
            // 
            // cgsLabel3
            // 
            this.cgsLabel3.AutoSize = true;
            this.cgsLabel3.Font = new System.Drawing.Font("Verdana", 8F);
            this.cgsLabel3.Location = new System.Drawing.Point(35, 203);
            this.cgsLabel3.Name = "cgsLabel3";
            this.cgsLabel3.Size = new System.Drawing.Size(137, 13);
            this.cgsLabel3.TabIndex = 11;
            this.cgsLabel3.Text = "Connection to Location";
            // 
            // cboConnections
            // 
            this.cboConnections.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboConnections.Font = new System.Drawing.Font("Verdana", 8F);
            this.cboConnections.FormattingEnabled = true;
            this.cboConnections.Location = new System.Drawing.Point(35, 219);
            this.cboConnections.Name = "cboConnections";
            this.cboConnections.Size = new System.Drawing.Size(267, 21);
            this.cboConnections.TabIndex = 2;
//            this.cboConnections.SelectedIndexChanged += new System.EventHandler(this.cboConnections_SelectedIndexChanged);
            // 
            // cgsFrmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(336, 360);
            this.Controls.Add(this.cboConnections);
            this.Controls.Add(this.cgsLabel3);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtUserID);
            this.Controls.Add(this.cgsLabel2);
            this.Controls.Add(this.cgsLabel1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "cgsFrmLogin";
            this.Text = "Login Screen";
            this.Load += new System.EventHandler(this.cgsFrmLogin_Load);
            this.Controls.SetChildIndex(this.btnContinue, 0);
            this.Controls.SetChildIndex(this.btnCancel, 0);
            this.Controls.SetChildIndex(this.pictureBox1, 0);
            this.Controls.SetChildIndex(this.cgsLabel1, 0);
            this.Controls.SetChildIndex(this.cgsLabel2, 0);
            this.Controls.SetChildIndex(this.txtUserID, 0);
            this.Controls.SetChildIndex(this.txtPassword, 0);
            this.Controls.SetChildIndex(this.cgsLabel3, 0);
            this.Controls.SetChildIndex(this.cboConnections, 0);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private CGS.Winforms.Controls.cgsLabel cgsLabel1;
        private CGS.Winforms.Controls.cgsLabel cgsLabel2;
        private CGS.Winforms.Controls.cgsLabel cgsLabel3;
        public CGS.Winforms.Controls.cgsMaskedTextBox txtUserID;
        public CGS.Winforms.Controls.cgsMaskedTextBox txtPassword;
        public CGS.Winforms.Controls.cgsComboBox cboConnections;
    }
}
