using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsApplication3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        


            DataSet ds = new DataSet();
            DataTable dt1 = new DataTable();
            DataTable dt2 = new DataTable();
            DataTable dt3 = new DataTable();
            dt1.TableName = "table1";
            dt2.TableName = "table2";
            dt3.TableName = "table3";

            dt1.Columns.Add("firstname", typeof(System.String));
            dt1.Columns.Add("pointer1", typeof(System.Int32));

            dt2.Columns.Add("pointer1", typeof(System.Int32));
            dt2.Columns.Add("pointer2", typeof(System.Int32));

            dt3.Columns.Add("pointer3", typeof(System.Int32));
            dt3.Columns.Add("testflag", typeof(System.Boolean));

            dt1.Rows.Add("kevin", 1);
            dt1.Rows.Add("steven", 2);
            dt1.Rows.Add("john", 3);

            dt2.Rows.Add(1, 100);
            dt2.Rows.Add(2, 200);
            dt2.Rows.Add(3, 300);

            dt3.Rows.Add(100, true);
            dt3.Rows.Add(200, false);
            dt3.Rows.Add(300, false);
            ds.Tables.Add(dt1);
            ds.Tables.Add(dt2);
            ds.Tables.Add(dt3);

             
       DataRelation datarelation1_2 =      ds.Relations.Add("relation1",dt1.Columns["pointer1"],dt2.Columns["pointer1"]);
       DataRelation datarelation2_3 =   ds.Relations.Add("relation2",dt2.Columns["pointer2"],dt3.Columns["pointer3"]);

            
            ds.Tables[1].DefaultView.RowFilter = "Child(table3).testflag = false ";



            DataRow[] drChildRowsTable2;
            DataRow[] drChildRowsTable3;
            bool lFoundRec = false;

            DataTable dtHits = new DataTable();
            dtHits.Columns.Add("firstname",typeof(System.String));


            foreach(DataRow drTable1 in ds.Tables["table1"].Rows) {
                lFoundRec = false;

                drChildRowsTable2 = drTable1.GetChildRows(datarelation1_2); {

                    foreach (DataRow dr2 in drChildRowsTable2)
                    {
                        drChildRowsTable3 = dr2.GetChildRows(datarelation2_3);
                        foreach (DataRow dr3 in drChildRowsTable3)
                            if (Convert.ToBoolean(dr3["testflag"]) == false)
                            {
                                lFoundRec = true;
                                break;
                            }
                    }
                }
                if(lFoundRec==true)
                    dtHits.Rows.Add( drTable1["firstname"]);
            }



            int xx = 0;

                 

        }
    }
}