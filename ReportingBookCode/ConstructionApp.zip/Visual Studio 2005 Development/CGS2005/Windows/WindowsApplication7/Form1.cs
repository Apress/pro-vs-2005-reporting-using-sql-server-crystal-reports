using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace WindowsApplication7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TextBox otemptext = new TextBox();
            otemptext = this.textBox1;

            ArrayList aa = new ArrayList();
            aa.Add(otemptext);



            TextBox oo = (TextBox)aa[0];
            oo.Text = "kevin";

           
        }
    }
}