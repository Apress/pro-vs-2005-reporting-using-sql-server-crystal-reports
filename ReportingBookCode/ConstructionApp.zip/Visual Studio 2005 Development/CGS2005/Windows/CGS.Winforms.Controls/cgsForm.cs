using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CGS.Winforms.Controls
{
    public partial class cgsForm : Form
    {
        public cgsForm()
        {
            InitializeComponent();
        }

        private void cgsForm_Load(object sender, EventArgs e)
        {

        }


        public virtual void SetMessageOn(string cMessage)
        {
            this.lblStatus.Text = cMessage;
            this.lblStatus.Visible = true;
            this.Update();
        }

        public virtual void SetMessageOff()
        {
            this.lblStatus.Visible = false;
            this.lblStatus.Text = "";
        }


    }
}