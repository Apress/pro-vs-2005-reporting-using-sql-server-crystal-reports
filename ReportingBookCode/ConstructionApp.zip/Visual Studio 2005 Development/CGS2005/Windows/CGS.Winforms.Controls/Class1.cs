using System;
using System.Collections.Generic;
using System.Text;

namespace CGS.Winforms.Controls
{
    public class Class1
    {
    }
}
