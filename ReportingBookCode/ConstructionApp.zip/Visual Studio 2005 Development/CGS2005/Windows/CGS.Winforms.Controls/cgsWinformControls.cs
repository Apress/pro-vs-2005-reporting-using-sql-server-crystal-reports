using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;


namespace CGS.Winforms.Controls
{
    public class cgsCheckedListBox : CheckedListBox
    {
        public cgsCheckedListBox()
        {
            // This call is required by the Windows.Forms Form Designer.
            this.Font = new Font("Verdana", 8);
            this.ThreeDCheckBoxes = true;

            // TODO: Add any initialization after the InitForm call
        }
    }




    public class cgsPanel : Panel
    {
        public cgsPanel()
        {
            this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;

            this.Anchor = ((System.Windows.Forms.AnchorStyles)((((
                System.Windows.Forms.AnchorStyles.Top
                | System.Windows.Forms.AnchorStyles.Bottom)
                | System.Windows.Forms.AnchorStyles.Left)
                | System.Windows.Forms.AnchorStyles.Right)));
        }
    }




    public class cgsLabel : Label
    {
        override public Font Font
        {
            get { return base.Font; }
            set { ; }
        }


        public cgsLabel()
        {
            base.Font = new Font("Verdana", 8);
        }
    }




    public class cgsDateTime : DateTimePicker
    {

        override public Font Font
        {
            get { return base.Font; }
            set { ; }
        }

        public cgsDateTime()
        {
            // This call is required by the Windows.Forms Form Designer.
            base.Font = new Font("Verdana", 8);
            this.Format = DateTimePickerFormat.Short;
            this.Width = 92;

            // TODO: Add any initialization after the InitForm call
        }


    }



    public class cgsButton : Button
    {

        override public Font Font
        {
            get { return base.Font; }
            set { ; }
        }


        public cgsButton()
        {
            base.Font = new Font("Verdana", 8);
            base.BackColor = Color.White;
        }
    }




    public class cgsMaskedTextBox : MaskedTextBox
    {

        public override Font Font
        {
            get { return base.Font; }
            set { base.Font = value; }
        }


        public cgsMaskedTextBox()
        {
            //this.CharacterCasing = CharacterCasing.Upper;
            base.Font = new Font("Verdana", 8);


            this.Enter += new EventHandler(OnEnter);
            this.Leave += new EventHandler(OnLeave);
            this.KeyDown += new KeyEventHandler(OnKeyDown);

        }



        public void OnKeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                SendKeys.Send("{TAB}");
        }


        public void OnEnter(object sender, EventArgs e)
        {
            this.SelectAll();
            if (this.ReadOnly == false)
                this.BackColor = Color.Yellow;
        }

        public void OnLeave(object sender, EventArgs e)
        {
            if (this.ReadOnly == false)
                this.BackColor = Color.White;
        }
    }




    public class cgsComboBox : ComboBox
    {
        override public Font Font
        {
            get { return base.Font; }
            set { ; }
        }

        public cgsComboBox()
        {
            base.Font = new Font("Verdana", 8);
            this.DropDownStyle = ComboBoxStyle.DropDownList;
        }
    }




    public class cgsCheckBox : CheckBox
    {
        override public Font Font
        {
            get { return base.Font; }
            set { ; }
        }



        public cgsCheckBox()
        {
            // This call is required by the Windows.Forms Form Designer.
            base.Font = new Font("Verdana", 8);
            this.Width = 88;

            // TODO: Add any initialization after the InitForm call
        }



    }


}
