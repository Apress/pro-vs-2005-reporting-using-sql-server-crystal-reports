using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CGS.Winforms.Forms
{
    public partial class cgsFrmApplication : CGS.Winforms.Controls.cgsForm
    {
        public cgsFrmApplication()
        {
            InitializeComponent();
        }
    }
}

