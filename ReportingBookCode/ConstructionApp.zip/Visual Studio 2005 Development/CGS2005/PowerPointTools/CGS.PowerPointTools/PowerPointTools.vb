Imports PowerPoint = Microsoft.Office.Interop.PowerPoint
Imports Excel = Microsoft.Office.Interop.Excel
Imports System.Drawing
Imports System.Collections.Generic



Public Class PowerPointTools

    Private _SlideNumber As Integer
    Public Property SlideNumber() As Integer
        Get
            Return _SlideNumber
        End Get
        Set(ByVal value As Integer)
            _SlideNumber = value
        End Set
    End Property


    Private _oPPTApp As PowerPoint.Application
    Public Property oPPTApp() As PowerPoint.Application
        Get
            Return _oPPTApp
        End Get
        Set(ByVal value As PowerPoint.Application)
            _oPPTApp = value
        End Set
    End Property

    Private _oPPTPres As PowerPoint.Presentation
    Public Property oPPTPres() As PowerPoint.Presentation
        Get
            Return _oPPTPres
        End Get
        Set(ByVal value As PowerPoint.Presentation)
            _oPPTPres = value
        End Set
    End Property

    Private _oExcel As Excel.Application
    Public Property oExcel() As Excel.Application
        Get
            Return _oExcel
        End Get
        Set(ByVal value As Excel.Application)
            _oExcel = value
        End Set
    End Property


    Private _oSheet As Excel.Worksheet
    Public Property oSheet() As Excel.Worksheet
        Get
            Return _oSheet
        End Get
        Set(ByVal value As Excel.Worksheet)
            _oSheet = value
        End Set
    End Property



    Public Sub LaunchPPT()
        '  Creates instances of PPT and Excel

        Me.oPPTApp = New PowerPoint.Application
        Me.oPPTApp.Visible = True


        Me.oExcel = New Excel.Application
        Me.oExcel.Visible = False

        Me.SlideNumber = 0

    End Sub

    Public Sub AddPicture(ByVal PicFile As String)
        Dim oBitmap As Bitmap
        oBitmap = New Bitmap(PicFile)
        Dim PicWidth As Int32
        Dim PicHeight As Int32

        PicWidth = oBitmap.Width
        PicHeight = oBitmap.Height

        Dim StartTop As Int32 = (540 - PicHeight) / 2
        Dim StartWidth As Int32 = (720 - PicWidth) / 2

        Me.oPPTApp.ActiveWindow.Selection.SlideRange.Shapes.AddPicture _
                         (PicFile, False, True, StartWidth, StartTop)

    End Sub

    Public Sub DisplayPPT()

        Me.oPPTApp.Visible = True
        Me.oPPTApp.WindowState = _
            PowerPoint.PpWindowState.ppWindowMaximized

        Me.oExcel = Nothing

    End Sub



    Public Sub SetTemplate(ByVal TemplateFilename As String)

        Me.oPPTPres = Me.oPPTApp.Presentations.Add

        Me.oPPTPres.ApplyTemplate(TemplateFilename)
        Me.AddSlide(PowerPoint.PpSlideLayout.ppLayoutTitle)

    End Sub



    Public Sub AddSlide(ByVal oLayout As PowerPoint.PpSlideLayout)
        ' Increment the active slide number,
        ' add a new slide based on that number/layout,
        ' and go to the slide

        Me.SlideNumber = Me.SlideNumber + 1
        Me.oPPTApp.ActivePresentation.Slides.Add(Me.SlideNumber, oLayout)
        Me.oPPTApp.ActiveWindow.View.GotoSlide(Me.SlideNumber)

    End Sub



    Public Sub BuildTitlePage(ByVal MainTitle As String, _
                                  ByVal SubTitleTemplate As String)

        Me.AddText("Rectangle 2", MainTitle)
        Me.AddText("Rectangle 3", SubTitleTemplate)

    End Sub

    Public Sub AddText(ByVal ShapeName As String, ByVal PPTText As String)

        Me.oPPTApp.ActiveWindow.Selection.SlideRange.Shapes(1).Select()
        Me.oPPTApp.ActiveWindow.Selection.TextRange.Text = PPTText

    End Sub


    Public Sub BuildBulletPage(ByVal MainTitle As String, _
                            ByVal BulletList As List(Of PPTBulletList))

        Me.AddSlide(PowerPoint.PpSlideLayout.ppLayoutText)

        Me.AddText("Rectangle 2", MainTitle)
        ' Note the indentlevel property, from the IndentLevel in the datatable source

        Me.SelectMainRectangle()

        Dim TextCounter As Int32 = 0

        For Each oBulletItem As PPTBulletList In BulletList
            oPPTApp.ActiveWindow.Selection.TextRange.InsertAfter( _
                                 oBulletItem.BulletItem + Chr(13))
            TextCounter = TextCounter + 1
            oPPTApp.ActiveWindow.Selection.TextRange.Paragraphs( _
                            TextCounter, 1).IndentLevel = oBulletItem.BulletItemIndent
        Next

    End Sub

    Public Sub BuildLineChartPage(ByVal MainTitle As String, _
                 ByVal DtLineChartData As DataTable, ByVal xAxisTitle As String, _
                 ByVal yAxisTitle As String)

        Me.AddSlide(PowerPoint.PpSlideLayout.ppLayoutChart)
        Me.AddText("Rectangle 2", MainTitle)
        Me.BuildExcelLineChart(DtLineChartData, xAxisTitle, yAxisTitle)
        Me.SelectMainRectangle()
        Me.oPPTApp.ActiveWindow.View.Paste()


    End Sub

    Public Sub BuildTablePieChartPage(ByVal MainTitle As String, _
                   ByVal DtTableEntries As DataTable, ByVal DtHeadings As DataTable, _
                   ByVal ChartTitle As String, ByVal DtPieChartData As DataTable)

        ' Add the slide, based on the Text/PieChart layout
        Me.AddSlide(PowerPoint.PpSlideLayout.ppLayoutTextAndChart)
        Me.AddText("Rectangle 2", MainTitle)

        ' Build the table, paste it into the slide
        Me.SelectMainRectangle()
        Me.BuildExcelTable(DtTableEntries, DtHeadings)
        Me.oPPTApp.ActiveWindow.View.Paste()

        ' Build the table for the Piechart, generate the chart, and paste the chart in
        Me.BuildExcelPieChart(DtPieChartData, ChartTitle)

        Me.oPPTApp.ActiveWindow.Selection.SlideRange.Shapes(3).Select()
        Me.oPPTApp.ActiveWindow.View.Paste()

    End Sub

    Public Sub SavePresentation(ByVal PPTName As String)

        Me.oPPTApp.ActivePresentation.SaveAs(PPTName)

    End Sub

    Public Sub SetSlideTransitions()

        ' Basic demonstration of looping through the slideshow collection
        ' use this as a guide to change settings at the slide level

        For Each oSlide As PowerPoint.Slide In Me.oPPTApp.ActivePresentation.Slides
            oSlide.SlideShowTransition.EntryEffect = _
                      PowerPoint.PpEntryEffect.ppEffectBlindsVertical
        Next

    End Sub


    Public Sub BuildFooter(ByVal FooterText As String)
        ' Possible enhancement could be making the slide number and date optional

        With Me.oPPTApp.ActivePresentation.SlideMaster.HeadersFooters
            .DateAndTime.Visible = True
            .DateAndTime.Format = _
                     PowerPoint.PpDateTimeFormat.ppDateTimeMMddyyhmmAMPM
            .DateAndTime.Text = ""
            .DateAndTime.UseFormat = True

            .Footer.Text = FooterText
            .SlideNumber.Visible = True
            .DisplayOnTitleSlide = False
        End With

    End Sub

    Public Sub BuildExcelPieChart(ByRef DtTableEntries As DataTable, _
                        ByRef ChartTitle As String)

        Dim TableCellRange As String
        TableCellRange = Me.BuildExcelTable(DtTableEntries)

        Me.oExcel.Charts.Add()

        Me.oExcel.ActiveChart.ApplyCustomType(Excel.XlChartType.xl3DPieExploded)

        'Me.oExcel.ActiveChart.ChartType = Excel.XlChartType.xl3DPie
        Me.oExcel.ActiveChart.SetSourceData(Me.oSheet.Range(TableCellRange), _
                           Excel.XlRowCol.xlColumns)

        Me.oExcel.ActiveChart.Location(Excel.XlChartLocation.xlLocationAsObject, _
                          "Sheet1")
        Me.oExcel.ActiveChart.HasTitle = True
        Me.oExcel.ActiveChart.ChartTitle.Characters.Text = ChartTitle
        Me.oExcel.ActiveChart.HasLegend = False

        Me.oExcel.ActiveChart.SeriesCollection(1).HasDataLabels = True
        oExcel.ActiveChart.ApplyDataLabels _
                 (Excel.XlDataLabelsType.xlDataLabelsShowLabelAndPercent)

        Me.oExcel.ActiveChart.PlotArea.Select()
        Me.oExcel.Selection.Interior.ColorIndex = 0
        Me.oExcel.Selection.Border.LineStyle = 0


        Me.oExcel.ActiveChart.ChartArea.Select()
        Me.oExcel.Selection.Interior.ColorIndex = 0
        Me.oExcel.Selection.Border.LineStyle = 0
        Me.oExcel.ActiveChart.ChartArea.Select()
        Me.oExcel.ActiveChart.ChartArea.Copy()


    End Sub



    Public Sub BuildBarChartPage(ByVal MainTitle As String, _
                ByVal DtBarChartData As DataTable, ByVal xAxisTitle As String, _
                ByVal yAxisTitle As String, ByVal DtBarChartHeadings As DataTable)

        Me.AddSlide(PowerPoint.PpSlideLayout.ppLayoutChart)
        Me.AddText("Rectangle 2", MainTitle)
        Me.BuildExcelBarChart(DtBarChartData, xAxisTitle, DtBarChartHeadings)
        Me.SelectMainRectangle()
        Me.oPPTApp.ActiveWindow.View.Paste()

    End Sub



    Public Sub BuildExcelBarChart(ByRef DtTableEntries As DataTable, _
              ByRef ChartTitle As String, ByRef DtHeadings As DataTable)

        Dim TableCellRange As String
        TableCellRange = Me.BuildExcelTable(DtTableEntries, DtHeadings)

        Me.oExcel.Charts.Add()

        Me.oExcel.ActiveChart.ApplyCustomType(Excel.XlChartType.xlColumnStacked)

        Me.oExcel.ActiveChart.SetSourceData(Me.oSheet.Range(TableCellRange), _
                Excel.XlRowCol.xlColumns)

        Me.oExcel.ActiveChart.Location(Excel.XlChartLocation.xlLocationAsObject, _
               "Sheet1")
        Me.oExcel.ActiveChart.HasTitle = True
        Me.oExcel.ActiveChart.ChartTitle.Characters.Text = ChartTitle

        Me.oExcel.ActiveChart.Axes(1).Select()
        Me.oExcel.Selection.TickLabels.Alignment = Excel.Constants.xlCenter
        Me.oExcel.Selection.TickLabels.Offset = 40
        Me.oExcel.Selection.TickLabels.Orientation = Excel.XlOrientation.xlUpward

        Me.oExcel.ActiveChart.SeriesCollection(5).Select()
        Me.oExcel.Selection.ChartType = Excel.XlChartType.xlLine

        Me.oExcel.ActiveChart.ChartArea.Select()
        Me.oExcel.Selection.Interior.ColorIndex = 0
        Me.oExcel.Selection.Border.LineStyle = 0

        Me.oExcel.ActiveChart.SeriesCollection(1).Select()
        Me.oExcel.Selection.Interior.ColorIndex = 4

        Me.oExcel.ActiveChart.SeriesCollection(2).Select()
        Me.oExcel.Selection.Interior.ColorIndex = 26

        Me.oExcel.ActiveChart.SeriesCollection(3).Select()
        Me.oExcel.Selection.Interior.ColorIndex = 27

        Me.oExcel.ActiveChart.SeriesCollection(4).Select()
        Me.oExcel.Selection.Interior.ColorIndex = 42

        Me.oExcel.ActiveChart.ChartArea.Select()
        Me.oExcel.ActiveChart.ChartArea.Copy()


    End Sub



    Public Sub BuildExcelLineChart(ByRef DtTableEntries As DataTable, ByRef xAxisTitle As String, ByRef yAxisTitle As String)


        Dim TableCellRange As String
        TableCellRange = Me.BuildExcelTable(DtTableEntries)

        Me.oExcel.Charts.Add()

        Me.oExcel.ActiveChart.ChartType = Excel.XlChartType.xlLineMarkers

        Me.oExcel.ActiveChart.Location(Excel.XlChartLocation.xlLocationAsObject, "Sheet1")

        '        Me.oExcel.ActiveChart.Axes(Excel.XlCategoryType.xlCategoryScale, Excel.XlAxisGroup.xlPrimary).HasTitle = True
        '        Me.oExcel.ActiveChart.Axes(Excel.XlCategoryType.xlCategoryScale, Excel.XlAxisGroup.xlPrimary).Text = xAxisTitle

        Me.oExcel.ActiveChart.PlotArea.Select()
        Me.oExcel.Selection.Interior.ColorIndex = 36  ' light yellow
        Me.oExcel.Selection.Border.LineStyle = 0


        Me.oExcel.ActiveChart.ChartArea.Select()
        Me.oExcel.Selection.Interior.ColorIndex = 0
        Me.oExcel.Selection.Border.LineStyle = 0


        Me.oExcel.ActiveChart.Axes(1).Select()
        Me.oExcel.Selection.TickLabels.Alignment = Excel.Constants.xlCenter
        Me.oExcel.Selection.TickLabels.Offset = 40
        '      Me.oExcel.Selection.ReadingOrder = Excel.Constants.xlContent
        Me.oExcel.Selection.TickLabels.Orientation = Excel.XlOrientation.xlUpward


        Me.oExcel.ActiveChart.ChartArea.Select()
        Me.oExcel.ActiveChart.ChartArea.Copy()


    End Sub



    Public Sub BuildTablePage(ByVal MainTitle As String, _
            ByVal DtTableEntries As DataTable, ByVal DtHeadings As DataTable)

        ' Create a new slide for the table page
        AddSlide(PowerPoint.PpSlideLayout.ppLayoutTable)


        ' Add the title inside the first shape
        AddText("Rectangle 2", MainTitle)

        ' Select the body shape
        Me.SelectMainRectangle()
        ' Generate the excel table from the table entries/headings
        Me.BuildExcelTable(DtTableEntries, DtHeadings)

        ' Paste the generated excel table
        Me.oPPTApp.ActiveWindow.View.Paste()



    End Sub

    Public Sub SelectMainRectangle()
        Me.oPPTApp.ActiveWindow.Selection.SlideRange.Shapes("Rectangle 3").Select()
    End Sub


    Function BuildExcelTable(ByVal DtTableEntries As DataTable) As String
        Dim EmptyTable As DataTable
        EmptyTable = New DataTable()
        Dim ReturnVal As String = BuildExcelTable(DtTableEntries, EmptyTable)
        Return ReturnVal
    End Function

    Function BuildExcelTable(ByVal DtTableEntries As DataTable, _
                ByVal DtHeadings As DataTable) As String

        ' Add a workbook, and reference the first sheet
        Dim oBook As Excel.Workbook = Me.oExcel.Workbooks.Add()
        Me.oSheet = oBook.Worksheets(1)

        Dim RowCounter As Int32 = 1
        Dim ColumnCounter As Int32 = 0
        Dim LastCell As String = ""
        Dim Cell As String = ""
        Dim Columnletter As String = ""
        Dim NumRows As Int32 = DtTableEntries.Rows.Count + 1

        ' Write out the column headings (if a heading table was provided)
        For Each Dr As DataRow In DtHeadings.Rows
            ' Determine cell
            Columnletter = Chr(Asc("A") + ColumnCounter)
            'Cell = Columnletter + RowCounter.ToString().Trim()
            Cell = Columnletter + "1"

            ColumnCounter += 1
            Me.WriteExcelCell(Me.oSheet.Range(Cell), Dr(0), True)

            ' Apply the alignment to the column
            Me.oSheet.Range(Columnletter + "1:" + _
                  Columnletter + NumRows.ToString().Trim()).Select()

            If Convert.ToBoolean(Dr(1)) = True Then
                Me.oExcel.Selection.HorizontalAlignment = 4
            Else
                Me.oExcel.Selection.HorizontalAlignment = 2
            End If
            'Me.oExcel.Selection.HorizontalAlignment = Dr(1)
        Next


        For Each Dr As DataRow In DtTableEntries.Rows
            RowCounter += 1
            ColumnCounter = 0
            For Each Dc As DataColumn In DtTableEntries.Columns
                Cell = Chr(Asc("A") + ColumnCounter) + RowCounter.ToString().Trim()
                LastCell = Cell
                ColumnCounter += 1
                Me.WriteExcelCell(Me.oSheet.Range(Cell), Dr(Dc), False)
            Next
        Next

        Me.oSheet.Range("A1:" + LastCell).Select()
        Me.oExcel.Selection.Copy()

        Return ("A1:" + LastCell)

    End Function




    Public Sub WriteExcelCell(ByVal oRange As Microsoft.Office.Interop.Excel.Range, _
               ByVal Col As Object, ByVal CellBold As Boolean)

        With oRange
            .Value = Col
            .Font.Name = "Verdana"
            .Font.Size = 12
            .Font.Bold = CellBold
        End With

    End Sub


End Class
