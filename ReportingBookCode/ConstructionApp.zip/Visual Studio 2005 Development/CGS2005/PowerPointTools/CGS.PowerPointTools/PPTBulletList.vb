Public Class PPTBulletList

    Public Enum IndentLevel
        NoIndent = 1
        Indent1 = 2
        Indent2 = 3
    End Enum


    Private BulletItemValue As String
    Public Property BulletItem() As String
        Get
            Return BulletItemValue
        End Get
        Set(ByVal value As String)
            BulletItemValue = value
        End Set
    End Property


    Private BulletItemIndentValue As Integer
    Public Property BulletItemIndent() As Integer
        Get
            Return BulletItemIndentValue
        End Get
        Set(ByVal value As Integer)
            BulletItemIndentValue = value
        End Set
    End Property




    Public Sub New(ByVal Bullet As String, ByVal Indent As IndentLevel)
        Me.BulletItemValue = Bullet
        Me.BulletItemIndentValue = Indent
    End Sub



End Class
