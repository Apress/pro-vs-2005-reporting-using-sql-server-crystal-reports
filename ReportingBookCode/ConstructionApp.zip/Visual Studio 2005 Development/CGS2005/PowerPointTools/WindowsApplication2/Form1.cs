using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataTable dtSource = new DataTable();
            dtSource.Columns.Add("firstname", typeof(System.String));
            dtSource.Rows.Add("Kevin");

            dtSource.DefaultView.RowFilter = "Firstname = 'Steve'";

            DataTable dtfilter = dtSource.DefaultView.ToTable();


        }
    }
}