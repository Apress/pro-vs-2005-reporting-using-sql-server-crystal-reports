// Copyright 2005, Kevin S. Goff - Common Ground Solutions
// You may use any or all functions as part of your .NET applications, in any way you see fit,
// SO LONG AS this paragraph is included.  
// No warranties or claims are made/offered
// regarding this framework, so use at your own risk.

// For questions, contact kgoff@commongroundsolutions.net



using System;

namespace CGS.Globals
{
    /// <summary>
    /// Summary description for Class1.
    /// </summary>
    public class cgsGlobals
    {
        private static bool _lAppRunning;
        public bool lAppRunning
        {
            get { return _lAppRunning; }
            set { _lAppRunning = value; }
        }

        private static string _cUserID;
        public string cUserID
        {
            get { return _cUserID; }
            set { _cUserID = value; }
        }


        private static int _nUserPK;
        public int nUserPK
        {
            get { return _nUserPK; }
            set { _nUserPK = value; }
        }




        private static string _cUserPassword;
        public string cUserPassword
        {
            get { return _cUserPassword; }
            set { _cUserPassword = value; }
        }

        private static string _cUserName;
        public string cUserName
        {
            get { return _cUserName; }
            set { _cUserName = value; }
        }



        private static string _cCurrentConnection;
        public string cCurrentConnection
        {
            get { return _cCurrentConnection; }
            set { _cCurrentConnection = value; }
        }

        private static int _nDataBaseKey;
        public int nDataBaseKey
        {
            get { return _nDataBaseKey; }
            set { _nDataBaseKey = value; }
        }



        public cgsGlobals()
        {
            //
            // TODO: Add constructor logic here
            //
            this.cUserID = "";
            this.cUserPassword = "";
            this.nDataBaseKey = 1;
        }
    }
}
