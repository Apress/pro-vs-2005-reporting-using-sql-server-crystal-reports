using System;
using System.Collections.Generic;
using System.Text;

namespace CGS.Business
{
    public class cgsBaseBusinessObject     : System.MarshalByRefObject 
    {
    		public cgsBaseBusinessObject()
  		    {
			// TODO: Add constructor logic here
  		    }
    }
}
