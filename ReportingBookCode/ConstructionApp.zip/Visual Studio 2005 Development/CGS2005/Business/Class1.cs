using System;
using System.Collections.Generic;
using System.Text;

namespace CGS.Business
{
    public class Class1
    {
    }
}
