using System;
using System.Collections.Generic;
using System.Text;

namespace CGS.RemoteAccess
{
    public class Class1
    {
    }
}
