using System;
using System.Data;
using System.Data.SqlClient;
using System.ComponentModel;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace CGS.DataAccess
{
     public class cgsDataAccess 
     {

 
     private SqlConnection GetConnection(int nDatabaseKey)
     {
          return  new SqlConnection(this.BuildDatabaseConnectionString
                  (nDatabaseKey)); 
     }

     public T ReadIntoTypedDs<T>(T dsTypedDs, string cStoredProc, 
                  List<SqlParameter> oParmList, int nDBKey) where T : DataSet
     {


            return this.ReadIntoTypedDs(dsTypedDs, cStoredProc, 
                                      oParmList, nDBKey, 0);
      }



     public T ReadIntoTypedDs<T>(T dsTypedDs, string cStoredProc, 
         List<SqlParameter> oParmList, int nDBKey, int nCommandTimeOut ) 
              where T : DataSet
      {

          SqlConnection oSqlConn = this.GetConnection(nDBKey); 
          SqlDataAdapter oSqlAdapter = new SqlDataAdapter(cStoredProc, oSqlConn);
          oSqlAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;

          if(nCommandTimeOut > 0)
               oSqlAdapter.SelectCommand.CommandTimeout = nCommandTimeOut;


          foreach (SqlParameter oParm in oParmList)
              oSqlAdapter.SelectCommand.Parameters.Add(oParm);

          int nTableCtr = 0;
          foreach (DataTable Dt in dsTypedDs.Tables)
          {
                string cSource = "";					
               // tricky part...first result set from sql is Table, 2nd is Table1,
               //  3rd, is Table2
               // So we have to check the counter and set the source string correctly
                if (nTableCtr == 0)
                    cSource = "Table";
                else
                    cSource = "Table" + nTableCtr.ToString().Trim();
                oSqlAdapter.TableMappings.Add(cSource, Dt.TableName.ToString());
                // set the mapping from the original table name 
                // to the corresponding one in our typed dS

                nTableCtr++;												
            }

            oSqlAdapter.Fill(dsTypedDs);
            oSqlConn.Close();

            return dsTypedDs;
        }


        public string BuildDatabaseConnectionString(int nDatabaseKey)
        {

             DataSet DsDatabaseInfo = new DataSet();
             AppDomain currentDomain = AppDomain.CurrentDomain;

             string cFileXml=currentDomain.BaseDirectory+"database.xml";
             DsDatabaseInfo.ReadXml(cFileXml);
             DsDatabaseInfo.Tables[0].PrimaryKey = 
                  new DataColumn[] {DsDatabaseInfo.Tables[0].Columns["DbKey"]};
             DataRow Dr = DsDatabaseInfo.Tables[0].Rows.Find(nDatabaseKey);

             SqlConnectionStringBuilder oStringBuilder = 
                              new SqlConnectionStringBuilder();
             oStringBuilder.UserID = Convert.ToString(Dr["UserID"]);
             oStringBuilder.Password = Convert.ToString(Dr["PassWord"]);
             oStringBuilder.InitialCatalog = 
                          Convert.ToString(Dr["InitialCatalog"]);
             oStringBuilder.DataSource = Convert.ToString(Dr["DataSource"]);
             oStringBuilder.ConnectTimeout = 
                         Convert.ToInt32(Dr["ConnectionTimeOut"]);
             oStringBuilder.MultipleActiveResultSets = 
                         Convert.ToBoolean(Dr["MultipleActiveResultSets"]);
            oStringBuilder.AsynchronousProcessing =  
                         Convert.ToBoolean(Dr["AsynchronousProcessing"]);

            return oStringBuilder.ConnectionString;

        }


     public cgsDataAccess()
     {
          // TODO: Add constructor logic here
      }
     }
}





















































//// Copyright 2005, Kevin S. Goff - Common Ground Solutions
//// You may use any or all functions as part of your .NET applications, in any way you see fit,
//// SO LONG AS this paragraph is included.  
//// No warranties or claims are made/offered
//// regarding this framework, so use at your own risk.

//// For questions, contact kgoff@commongroundsolutions.net



//using System;
//using System.Data;
//using System.Data.SqlClient;
//using System.ComponentModel;
//using System.Collections;
//using System.Collections.Generic;

//namespace CGS.DataAccess
//{
//    /// <summary>
//    /// Summary description for DataAccess.
//    /// </summary>
//    public class cgsDataAccess 
//    {

 
//        private SqlConnection GetConnection(int nDatabaseKey)
//        {
//            return  new SqlConnection(this.BuildDatabaseConnectionString(nDatabaseKey)); 

			
//        }

//        public T ReadIntoTypedDs<T>(T dsTypedDs, string cStoredProc, List<SqlParameter> oParmList, int nDBKey) where T : DataSet
//        {
//            return this.ReadIntoTypedDs(dsTypedDs, cStoredProc, oParmList, nDBKey, 0);
//        }



//        public T ReadIntoTypedDs<T>(T dsTypedDs, string cStoredProc, List<SqlParameter> oParmList, int nDBKey, int nCommandTimeOut ) where T : DataSet
//        {

//            SqlConnection oSqlConn = this.GetConnection(nDBKey); 
//            SqlDataAdapter oSqlAdapter = new SqlDataAdapter(cStoredProc, oSqlConn);
//            oSqlAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;

//            if(nCommandTimeOut > 0)
//                oSqlAdapter.SelectCommand.CommandTimeout = nCommandTimeOut;


//            foreach (SqlParameter oParm in oParmList)
//                oSqlAdapter.SelectCommand.Parameters.Add(oParm);

//            int nTableCtr = 0;
//            foreach (DataTable Dt in dsTypedDs.Tables)
//            {
//                string cSource = "";					
//                // tricky part...first result set from sql is Table, 2nd is Table1, 3rd, is Table2
//                // So we have to check the counter and set the source string correctly
//                if (nTableCtr == 0)
//                    cSource = "Table";
//                else
//                    cSource = "Table" + nTableCtr.ToString().Trim();
//                oSqlAdapter.TableMappings.Add(cSource, Dt.TableName.ToString());	
//                // set the mapping from the original table name to the corresponding one 
//                // in our typed dS

//                nTableCtr++;												
//            }

//            oSqlAdapter.Fill(dsTypedDs);

//            oSqlConn.Close();

//            return dsTypedDs;
//        }


//        public string BuildDatabaseConnectionString(int nDatabaseKey)
//        {

//            DataSet DsDatabaseInfo = new DataSet();

//            AppDomain currentDomain = AppDomain.CurrentDomain;

//            string cFileXml=currentDomain.BaseDirectory+"database.xml";

//            DsDatabaseInfo.ReadXml(cFileXml);
//            DsDatabaseInfo.Tables[0].PrimaryKey = new DataColumn[] {DsDatabaseInfo.Tables[0].Columns["DbKey"]};
//            DataRow Dr = DsDatabaseInfo.Tables[0].Rows.Find(nDatabaseKey);

//            SqlConnectionStringBuilder oStringBuilder = new SqlConnectionStringBuilder();
//            oStringBuilder.UserID = Convert.ToString(Dr["UserID"]);
//            oStringBuilder.Password = Convert.ToString(Dr["PassWord"]);
//            oStringBuilder.InitialCatalog = Convert.ToString(Dr["InitialCatalog"]);
//            oStringBuilder.DataSource = Convert.ToString(Dr["DataSource"]);
//            oStringBuilder.ConnectTimeout = Convert.ToInt32(Dr["ConnectionTimeOut"]);
//            oStringBuilder.MultipleActiveResultSets = Convert.ToBoolean(Dr["MultipleActiveResultSets"]);
//            oStringBuilder.AsynchronousProcessing = Convert.ToBoolean(Dr["AsynchronousProcessing"]);

//            return oStringBuilder.ConnectionString;

//        }



 


//        public cgsDataAccess()
//        {
//            //
//            // TODO: Add constructor logic here
//            //
//        }
//    }
//}
