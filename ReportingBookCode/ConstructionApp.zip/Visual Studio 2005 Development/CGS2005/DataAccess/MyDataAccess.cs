using System;
using System.Data;
using System.Data.SqlClient;
using System.ComponentModel;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace MyApplication.MyDataAccess
{
    public class MyDataAccess
    {


        private SqlConnection GetConnection()
        {
            return new SqlConnection(this.BuildDatabaseConnectionString  ());
        }


        public string BuildDatabaseConnectionString()
        {

            DataSet DsDatabaseInfo = new DataSet();
            AppDomain currentDomain = AppDomain.CurrentDomain;

            string cUserID, cPassWord, cDataSource, cInitialCatalog;
            int nStandardTimeout;
            bool lAsyncProcessing, lMultipleActiveResultSets;

            cUserID = "KEVIN";
            cPassWord = "KEVINPW";
            cDataSource = "MYDBSERVER";
            cInitialCatalog = "MYDATABASE";
            nStandardTimeout = 30;
            lAsyncProcessing = true;
            lMultipleActiveResultSets = true;


            SqlConnectionStringBuilder oStringBuilder = new SqlConnectionStringBuilder();

            oStringBuilder.UserID = cUserID;
            oStringBuilder.Password = cPassWord;
            oStringBuilder.InitialCatalog = cInitialCatalog;
            oStringBuilder.DataSource = cDataSource;
            oStringBuilder.ConnectTimeout = nStandardTimeout;
            oStringBuilder.MultipleActiveResultSets = lMultipleActiveResultSets;
            oStringBuilder.AsynchronousProcessing = lAsyncProcessing;

            return oStringBuilder.ConnectionString;

        }

      


        public DataSet RetrieveFromSP(string cStoredProc, List<SqlParameter> oParmList, int nCommandTimeOut)
        {

            DataSet dsReturn = new DataSet();

            SqlConnection oSqlConn = this.GetConnection();
            SqlDataAdapter oSqlAdapter = new SqlDataAdapter(cStoredProc, oSqlConn);
            oSqlAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            if (nCommandTimeOut > 0)
                oSqlAdapter.SelectCommand.CommandTimeout = nCommandTimeOut;

            foreach (SqlParameter oParm in oParmList)
                oSqlAdapter.SelectCommand.Parameters.Add(oParm);


            oSqlAdapter.Fill(dsReturn);
            oSqlConn.Close();

            return dsReturn;
        }


   


        public MyDataAccess()
        {
            // TODO: Add constructor logic here
        }
    }
}











































