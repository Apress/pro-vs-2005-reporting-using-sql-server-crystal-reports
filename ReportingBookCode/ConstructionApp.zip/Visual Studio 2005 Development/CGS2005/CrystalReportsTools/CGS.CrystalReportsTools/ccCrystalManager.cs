// Copyright 2005, Kevin S. Goff - Common Ground Solutions
// You may use any or all functions as part of your .NET applications, in any way you see fit,
// SO LONG AS this paragraph is included.  
// No warranties or claims are made/offered
// regarding this framework, so use at your own risk.

// For questions, contact kgoff@commongroundsolutions.net




using System;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Data;
using System.Windows.Forms;
using System.Collections;
using CrystalDecisions.Windows.Forms;
 

namespace CGS.CrystalReportsTools 
{	
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	/// 

	// properties 

	public class ccCrystalManager
	{


        public enum ExportTypes
        {
            PDF = 1,
            MSWord = 2,
            MSExcel = 3, 
            HTML = 4

        }


		// properties utilized by the generic print routine


		private static string  _cPrinterName;
		public string cPrinterName
		{
			get {return _cPrinterName ;}
			set {_cPrinterName = value;}
		}


		private static int  _nCopies;
		public int nCopies
		{
			get {return _nCopies ;}
			set {_nCopies = value;}
		}

		private static bool  _lAllPages;
		public bool lAllPages
		{
			get {return _lAllPages ;}
			set {_lAllPages = value;}
		}


		private static bool  _lPageRange;
		public bool lPageRange
		{
			get {return _lPageRange ;}
			set {_lPageRange = value;}
		}


		private static int  _nStartPage;
		public int nStartPage
		{
			get {return _nStartPage ;}
			set {_nStartPage = value;}
		}

		private static int  _nEndPage;
		public int nEndPage
		{
			get {return _nEndPage ;}
			set {_nEndPage = value;}
		}

		private static bool  _lCollate;
		public bool lCollate
		{
			get {return _lCollate ;}
			set {_lCollate = value;}
		}




        public ccCrystalManager()
		{
			this.nCopies = 1;
			this.nStartPage = 0;
			this.nEndPage = 0;


			this.cPrinterName = "";
			this.lAllPages = true;
			this.lPageRange = false;
			this.lCollate = true;
 
		
		}






		public ReportDocument PushReportData(DataSet DsReportData, ReportDocument oReport)
		{
			// Called when a report is generated
			//	Calls SetData for the main report object
			//	Also calls SetData for any subreport objects

            
			this.SetData(DsReportData,oReport);

			foreach(ReportDocument oSubReport in oReport.Subreports) 
				this.SetData(DsReportData,oSubReport);
 
			return oReport;

		}

        private void SetData(DataSet DsReportData, ReportDocument oReport)
        {
            // receives a DataSet and a report object (could be the main object, could be a subreport object)

            // loops through the report object's tables collection, 
            // matches up the table name with the corresponding table name in the dataset,
            // and set sthe datasource accordingly

            // This function eliminates the need for a developer to know the specific table order
            // in the report

            foreach (Table oTable in oReport.Database.Tables)
                          oTable.SetDataSource(DsReportData.Tables[oTable.Name.ToString()]);

        }





        public void SetReportInfo(ReportDocument oReport2, ccReportInfo oReportInfo)
        {

            // This is a typed dataset that's also part of the             
            DsReportInfo odsReportInfo = new DsReportInfo();
            DsReportInfo.dtReportInfoRow oHeaderFooterRow = odsReportInfo.dtReportInfo.NewdtReportInfoRow();


            oHeaderFooterRow.FtrDataSource = oReportInfo.FtrDataSource;
            oHeaderFooterRow.FtrFootNotes = oReportInfo.FtrFootNotes;
            oHeaderFooterRow.FtrRunBy = oReportInfo.FtrRunBy;
            oHeaderFooterRow.FtrVersion = oReportInfo.FtrVersion;
            oHeaderFooterRow.HdrCompany = oReportInfo.HdrCompany;
            oHeaderFooterRow.HdrReportTitle = oReportInfo.HdrReportTitle;
            oHeaderFooterRow.HdrSubTitle1 = oReportInfo.HdrSubTitle1;
            oHeaderFooterRow.HdrSubTitle2 = oReportInfo.HdrSubTitle2;
            oHeaderFooterRow.UserID = oReportInfo.UserID;
            odsReportInfo.dtReportInfo.AdddtReportInfoRow(oHeaderFooterRow);

            this.PushReportData(odsReportInfo, oReport2);

             





        }



        public ccCrystalViewer PreviewReport(ReportDocument oReport, string cTitle, DataSet DsReportData)
        {
            // Overload of PreviewReport, if we want to push the data
            // and then run the report in one method
            this.PushReportData(DsReportData, oReport);
            
            return this.PreviewReport(oReport, cTitle);

        }



        public ccCrystalViewer PreviewReport(ReportDocument oReport, string cTitle)
        {
            ccCrystalViewer oViewer = new ccCrystalViewer();
            oViewer.crViewer.ReportSource = oReport;
            oViewer.crViewer.Zoom(100);
            oViewer.Text = cTitle;
            oViewer.ShowDialog();

            return oViewer;
        }





        public void PrintReport(ReportDocument oReport)
        {
            oReport.PrintOptions.PrinterName = this.cPrinterName;


            oReport.PrintToPrinter(this.nCopies, this.lCollate, this.nStartPage, this.nEndPage);

}






        public void ExportReport(ReportDocument oReport,string cFileName, ExportTypes oExportTypes) 
        {
            this.ExportReport(oReport, cFileName,oExportTypes,0,0);
        }


   


        public void ExportReport(ReportDocument oReport, string cFileName, ExportTypes oExportTypes, int nFirstPage, int nLastPage)
        {
            ExportOptions oExportOptions = new ExportOptions();
            PdfRtfWordFormatOptions oFormatOptions = ExportOptions.CreatePdfRtfWordFormatOptions();
            DiskFileDestinationOptions oDestinationOptions = ExportOptions.CreateDiskFileDestinationOptions();

            switch (oExportTypes)
            {
                case ExportTypes.PDF:
                case ExportTypes.MSWord:
                    oExportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
                    PdfRtfWordFormatOptions oPDFFormatOptions = ExportOptions.CreatePdfRtfWordFormatOptions();

                    // this code for setting page range is repeated for the different export types
                    // It would be great to use .NET generics, but the different export types
                    // don't implement a common interface
                    if (nFirstPage > 0 && nLastPage > 0)
                    {
                        oPDFFormatOptions.FirstPageNumber = nFirstPage;
                        oPDFFormatOptions.LastPageNumber = nLastPage;
                        oPDFFormatOptions.UsePageRange = true;
                    }
                   oExportOptions.ExportFormatOptions = oPDFFormatOptions;
                   break;

                case ExportTypes.MSExcel:
                    oExportOptions.ExportFormatType = ExportFormatType.Excel;
                    ExcelFormatOptions oExcelFormatOptions = ExportOptions.CreateExcelFormatOptions();

                    if (nFirstPage > 0 && nLastPage > 0)
                    {
                        oExcelFormatOptions.FirstPageNumber = nFirstPage;
                        oExcelFormatOptions.LastPageNumber = nLastPage;
                        oExcelFormatOptions.UsePageRange = true;
                    }
                   oExcelFormatOptions.ExcelUseConstantColumnWidth = false;
                   oExportOptions.ExportFormatOptions = oExcelFormatOptions;
                   break;
                case ExportTypes.HTML:
                    oExportOptions.ExportFormatType = ExportFormatType.HTML40;
                    HTMLFormatOptions oHTMLFormatOptions = ExportOptions.CreateHTMLFormatOptions();
                    if (nFirstPage > 0 && nLastPage > 0)
                    {
                        oHTMLFormatOptions.FirstPageNumber = nFirstPage;
                        oHTMLFormatOptions.LastPageNumber = nLastPage;
                        oHTMLFormatOptions.UsePageRange = true;
                    }
                    // can set additional HTML export options here

                    oExportOptions.ExportFormatOptions = oHTMLFormatOptions;
                    break;
            }
           
 
            oDestinationOptions.DiskFileName = cFileName;
            oExportOptions.ExportDestinationOptions = oDestinationOptions;
            oExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
           
            oReport.Export(oExportOptions);



        }
 

	}
}
