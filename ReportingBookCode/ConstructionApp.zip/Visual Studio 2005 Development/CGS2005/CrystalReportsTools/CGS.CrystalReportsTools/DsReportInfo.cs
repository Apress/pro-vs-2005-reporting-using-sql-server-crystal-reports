﻿namespace CGS.CrystalReportsTools {


    partial class DsReportInfo
    {
    }
}
