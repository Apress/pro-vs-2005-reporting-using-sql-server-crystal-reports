// Copyright 2005, Kevin S. Goff - Common Ground Solutions
// You may use any or all functions as part of your .NET applications, in any way you see fit,
// SO LONG AS this paragraph is included.  
// No warranties or claims are made/offered
// regarding this framework, so use at your own risk.

// For questions, contact kgoff@commongroundsolutions.net


using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Drawing.Printing;


namespace CGS.CrystalReportsTools 
{
	/// <summary>
	/// Summary description for ccCrystalPrintOptionForm.
	/// </summary>
	public class ccCrystalPrintOptionForm : System.Windows.Forms.Form
	{

		ccCrystalManager oCrystalManager ;
		 
	
		
	
		
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        public ComboBox cboPrinterTray;
        private System.Windows.Forms.Button btnCancel;
        public ComboBox cboPrinterList;
        public NumericUpDown spnNumPrintedCopies;
        public CheckBox chkCollateCopies;
		private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.GroupBox groupBox1;
        public RadioButton optPrintAll;
        public RadioButton optPrintRange;
        public TextBox txtPrintStartPage;
        public TextBox txtPrintEndPage;
		private System.Windows.Forms.Label label3;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ccCrystalPrintOptionForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ccCrystalPrintOptionForm));
            this.label1 = new System.Windows.Forms.Label();
            this.cboPrinterList = new System.Windows.Forms.ComboBox();
            this.spnNumPrintedCopies = new System.Windows.Forms.NumericUpDown();
            this.chkCollateCopies = new System.Windows.Forms.CheckBox();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cboPrinterTray = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPrintEndPage = new System.Windows.Forms.TextBox();
            this.txtPrintStartPage = new System.Windows.Forms.TextBox();
            this.optPrintRange = new System.Windows.Forms.RadioButton();
            this.optPrintAll = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.spnNumPrintedCopies)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select Printer";
            // 
            // cboPrinterList
            // 
            this.cboPrinterList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPrinterList.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboPrinterList.Location = new System.Drawing.Point(104, 13);
            this.cboPrinterList.Name = "cboPrinterList";
            this.cboPrinterList.Size = new System.Drawing.Size(312, 21);
            this.cboPrinterList.TabIndex = 0;
            // 
            // spnNumPrintedCopies
            // 
            this.spnNumPrintedCopies.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.spnNumPrintedCopies.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spnNumPrintedCopies.Location = new System.Drawing.Point(368, 80);
            this.spnNumPrintedCopies.Name = "spnNumPrintedCopies";
            this.spnNumPrintedCopies.ReadOnly = true;
            this.spnNumPrintedCopies.Size = new System.Drawing.Size(48, 21);
            this.spnNumPrintedCopies.TabIndex = 2;
            this.spnNumPrintedCopies.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // chkCollateCopies
            // 
            this.chkCollateCopies.Checked = true;
            this.chkCollateCopies.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkCollateCopies.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCollateCopies.Location = new System.Drawing.Point(312, 127);
            this.chkCollateCopies.Name = "chkCollateCopies";
            this.chkCollateCopies.Size = new System.Drawing.Size(104, 24);
            this.chkCollateCopies.TabIndex = 3;
            this.chkCollateCopies.Text = "Collate Copies";
            // 
            // btnPrint
            // 
            this.btnPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnPrint.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnPrint.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.Image = ((System.Drawing.Image)(resources.GetObject("btnPrint.Image")));
            this.btnPrint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPrint.Location = new System.Drawing.Point(112, 232);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(88, 23);
            this.btnPrint.TabIndex = 5;
            this.btnPrint.Text = "    Print";
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
            this.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancel.Location = new System.Drawing.Point(232, 232);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(88, 23);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "    Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(304, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "# Copies";
            // 
            // cboPrinterTray
            // 
            this.cboPrinterTray.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPrinterTray.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboPrinterTray.Items.AddRange(new object[] {
            "Automatic",
            "Upper Tray",
            "Lower Tray"});
            this.cboPrinterTray.Location = new System.Drawing.Point(104, 176);
            this.cboPrinterTray.Name = "cboPrinterTray";
            this.cboPrinterTray.Size = new System.Drawing.Size(312, 21);
            this.cboPrinterTray.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(16, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Paper Tray";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtPrintEndPage);
            this.groupBox1.Controls.Add(this.txtPrintStartPage);
            this.groupBox1.Controls.Add(this.optPrintRange);
            this.groupBox1.Controls.Add(this.optPrintAll);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(16, 64);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(272, 88);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Print Range Option";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(192, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "to";
            // 
            // txtPrintEndPage
            // 
            this.txtPrintEndPage.Enabled = false;
            this.txtPrintEndPage.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrintEndPage.Location = new System.Drawing.Point(216, 59);
            this.txtPrintEndPage.Name = "txtPrintEndPage";
            this.txtPrintEndPage.Size = new System.Drawing.Size(40, 21);
            this.txtPrintEndPage.TabIndex = 3;
            this.txtPrintEndPage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtPrintStartPage
            // 
            this.txtPrintStartPage.Enabled = false;
            this.txtPrintStartPage.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrintStartPage.Location = new System.Drawing.Point(144, 58);
            this.txtPrintStartPage.Name = "txtPrintStartPage";
            this.txtPrintStartPage.Size = new System.Drawing.Size(40, 21);
            this.txtPrintStartPage.TabIndex = 2;
            this.txtPrintStartPage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // optPrintRange
            // 
            this.optPrintRange.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optPrintRange.Location = new System.Drawing.Point(16, 56);
            this.optPrintRange.Name = "optPrintRange";
            this.optPrintRange.Size = new System.Drawing.Size(128, 24);
            this.optPrintRange.TabIndex = 1;
            this.optPrintRange.Text = "Print From Page";
            this.optPrintRange.Click += new System.EventHandler(this.optPrintRange_Click_1);
            // 
            // optPrintAll
            // 
            this.optPrintAll.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optPrintAll.Location = new System.Drawing.Point(16, 24);
            this.optPrintAll.Name = "optPrintAll";
            this.optPrintAll.Size = new System.Drawing.Size(104, 24);
            this.optPrintAll.TabIndex = 0;
            this.optPrintAll.Text = "Print All Pages";
            this.optPrintAll.Click += new System.EventHandler(this.optPrintAll_Click_1);
            this.optPrintAll.CheckedChanged += new System.EventHandler(this.optPrintAll_CheckedChanged);
            // 
            // ccCrystalPrintOptionForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(432, 262);
            this.ControlBox = false;
            this.Controls.Add(this.cboPrinterTray);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.chkCollateCopies);
            this.Controls.Add(this.spnNumPrintedCopies);
            this.Controls.Add(this.cboPrinterList);
            this.Controls.Add(this.groupBox1);
            this.Name = "ccCrystalPrintOptionForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Print Options";
            this.Load += new System.EventHandler(this.ccCrystalPrintOptionForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.spnNumPrintedCopies)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		private void ccCrystalPrintOptionForm_Load(object sender, System.EventArgs e)
		{
			 
			this.SetControlBindings();
			this.PopulatePrinterList();
		}



		private void SetControlBindings()
		{
			oCrystalManager = new ccCrystalManager();
			// Bind the options to the Crystal Manager properties
			this.cboPrinterList.DataBindings.Add("Text",oCrystalManager,"cPrinterName");

			this.optPrintAll.DataBindings.Add("Checked",oCrystalManager,"lAllPages");
			this.optPrintRange.DataBindings.Add("Checked",oCrystalManager,"lPageRange");

			this.chkCollateCopies.DataBindings.Add("Checked",oCrystalManager,"lCollate");
			this.txtPrintStartPage.DataBindings.Add("Text",oCrystalManager,"nStartPage");
			this.txtPrintEndPage.DataBindings.Add("Text",oCrystalManager,"nEndPage");
			this.spnNumPrintedCopies.DataBindings.Add("Value",oCrystalManager,"nCopies");

		}



		private void PopulatePrinterList()
		{


			PrintDocument prtdoc = new PrintDocument();
			// get the current default printer, we'll make that the default in the dropdown
			string strDefaultPrinter = prtdoc.PrinterSettings.PrinterName;

			int nCtr = 0;
			// get list of installed printers
 			foreach(String cPrinter in 
				PrinterSettings.InstalledPrinters) 
			{
				this.cboPrinterList.Items.Add(cPrinter);
				if(cPrinter==strDefaultPrinter)
					this.cboPrinterList.SelectedIndex = nCtr;
				nCtr++;
				
			}

			



		}
 

		private void button2_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void btnContinue_Click(object sender, System.EventArgs e)
		{
			this.Close();

		}

		private void HandleAllPages()
		{




			if(this.optPrintAll.Checked==true) 
			{
				this.txtPrintStartPage.ReadOnly = true;
				this.txtPrintEndPage.Enabled = false;
				this.txtPrintEndPage.ReadOnly = true;
				this.txtPrintStartPage.Enabled = false;
				this.txtPrintEndPage.Text = "0";
				this.txtPrintEndPage.Text = "0";
				oCrystalManager.lAllPages = true;
				oCrystalManager.lPageRange = false;
			}
			else 
			{
				this.txtPrintStartPage.ReadOnly = false;
				this.txtPrintEndPage.Enabled = true;

				this.txtPrintEndPage.ReadOnly = false;
				this.txtPrintStartPage.Enabled = true;

				oCrystalManager.lAllPages = false;
				oCrystalManager.lPageRange = true;


			}

 
		}

		private void optPrintAll_Click(object sender, System.EventArgs e)
		{
			this.HandleAllPages();
		}

		private void optPrintRange_Click(object sender, System.EventArgs e)
		{
			this.HandleAllPages();

		}

		private void optPrintAll_Click_1(object sender, System.EventArgs e)
		{
			this.HandleAllPages();
		}

		private void optPrintRange_Click_1(object sender, System.EventArgs e)
		{
			this.HandleAllPages();

		}

		private void optPrintAll_CheckedChanged(object sender, System.EventArgs e)
		{
			int xx = 0;
		}

		


	}
}
