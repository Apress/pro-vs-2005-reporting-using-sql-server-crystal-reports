
// Copyright 2005, Kevin S. Goff - Common Ground Solutions
// You may use any or all functions as part of your .NET applications, in any way you see fit,
// SO LONG AS this paragraph is included.  
// No warranties or claims are made/offered
// regarding this framework, so use at your own risk.

// For questions, contact kgoff@commongroundsolutions.net


using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CGS.CrystalReportsTools 
{
	/// <summary>
	/// Summary description for ccCrystalViewer.
	/// </summary>
	public class ccCrystalViewer : System.Windows.Forms.Form
    {
        internal CrystalDecisions.Windows.Forms.CrystalReportViewer crViewer;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ccCrystalViewer()
		{
		 
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			ccCrystalManager oCrystalManager = new ccCrystalManager();
          //  oCrystalManager.RegisterControls2(this.crViewer);


			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.crViewer = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // crViewer
            // 
            this.crViewer.ActiveViewIndex = -1;
            this.crViewer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.crViewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crViewer.DisplayGroupTree = false;
            this.crViewer.DisplayStatusBar = false;
            this.crViewer.Location = new System.Drawing.Point(-4, 12);
            this.crViewer.Name = "crViewer";
            this.crViewer.SelectionFormula = "";
            this.crViewer.ShowRefreshButton = false;
            this.crViewer.Size = new System.Drawing.Size(912, 520);
            this.crViewer.TabIndex = 0;
            this.crViewer.ViewTimeSelectionFormula = "";
            this.crViewer.Load += new System.EventHandler(this.crViewer_Load);
            // 
            // ccCrystalViewer
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(920, 534);
            this.Controls.Add(this.crViewer);
            this.Name = "ccCrystalViewer";
            this.Text = "ccCrystalViewer";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

		}
		#endregion

		private void crViewer_Load(object sender, System.EventArgs e)
		{
			 
		}

		private void crViewer_Click()
		{
		}


		private void crViewer_CloseView( )
		{
			MessageBox.Show("Closed");
		}

		



	}
}
